import { base44 } from './base44Client';


export const ScanResult = base44.entities.ScanResult;

export const UserProfile = base44.entities.UserProfile;



// auth sdk:
export const User = base44.auth;