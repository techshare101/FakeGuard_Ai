import React, { useEffect, useState } from "react";
import { UserProfile } from "@/api/entities";

export default function StripeWebhook() {
  const [status, setStatus] = useState({ processed: false, message: "Processing webhook..." });

  useEffect(() => {
    // This function will handle the Stripe webhook data
    const processWebhook = async () => {
      try {
        const urlParams = new URLSearchParams(window.location.search);
        const event = urlParams.get('event');
        const customerId = urlParams.get('customer');
        const userEmail = urlParams.get('email');
        const planType = urlParams.get('plan_type'); // 'subscription' or 'one_time'
        const scanCount = urlParams.get('scan_count'); // for one-time purchases
        const signature = urlParams.get('signature'); // webhook signature
        
        // Using the provided webhook secret
        const webhookSecret = "whsec_U5G0KeAXSK5kGEOVf6yrufD9SuPmkPX9";
        
        console.log("Webhook received:", { event, customerId, userEmail, planType, scanCount });
        
        if (event === 'checkout.session.completed' && userEmail) {
          // Find user profile by email
          const userProfiles = await UserProfile.filter({ created_by: userEmail });
          
          if (userProfiles.length === 0) {
            // Create new profile
            await UserProfile.create({
              created_by: userEmail,
              subscription_active: planType === 'subscription',
              available_scans: planType === 'subscription' ? 0 : parseInt(scanCount || '5'),
              subscription_end_date: planType === 'subscription' ? 
                new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() : null,
              payment_status: 'paid',
              total_scans: 0,
              successful_detections: 0,
              stripe_customer_id: customerId
            });
          } else {
            // Update existing profile
            await UserProfile.update(userProfiles[0].id, {
              subscription_active: planType === 'subscription',
              available_scans: planType === 'subscription' ? 0 : 
                (userProfiles[0].available_scans + parseInt(scanCount || '5')),
              subscription_end_date: planType === 'subscription' ? 
                new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() : null,
              payment_status: 'paid',
              stripe_customer_id: customerId
            });
          }
          
          setStatus({ 
            processed: true, 
            message: "Webhook processed successfully. Customer account has been activated."
          });
        } else if (event === 'customer.subscription.deleted' && customerId) {
          // Handle subscription cancellation
          const userProfiles = await UserProfile.filter({ stripe_customer_id: customerId });
          
          if (userProfiles.length > 0) {
            await UserProfile.update(userProfiles[0].id, {
              subscription_active: false,
              subscription_end_date: null
            });
            
            setStatus({ 
              processed: true, 
              message: "Subscription cancellation processed successfully."
            });
          } else {
            setStatus({ 
              processed: true, 
              message: "Customer not found for cancellation event."
            });
          }
        } else {
          setStatus({ 
            processed: true, 
            message: "Webhook received but no action taken. Event type not handled."
          });
        }
      } catch (error) {
        console.error('Error processing webhook:', error);
        setStatus({ 
          processed: true, 
          message: `Error processing webhook: ${error.message}`
        });
      }
    };

    processWebhook();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full text-center">
        <h1 className="text-2xl font-bold mb-4">Stripe Webhook Handler</h1>
        <p className="text-gray-700 mb-2">{status.message}</p>
        {status.processed && (
          <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-800">
            Webhook processed at {new Date().toLocaleString()}
          </div>
        )}
      </div>
    </div>
  );
}