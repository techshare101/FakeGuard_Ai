
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { UserProfile } from "@/api/entities";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  UserCircle, 
  Mail, 
  Calendar,
  Award,
  Scan,
  Shield,
  AlertTriangle,
  ArrowUpRight
} from "lucide-react";
import { createPageUrl } from "@/utils";
import Footer from "../components/legal/Footer";

export default function Profile() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      const profiles = await UserProfile.filter({ created_by: userData.email });
      if (profiles.length > 0) {
        setProfile(profiles[0]);
      }
    } catch (error) {
      console.error("Error loading profile:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return <div className="p-8">Loading profile data...</div>;
  }

  const getExpertiseLevel = (scans) => {
    if (scans >= 100) return "Expert Scanner";
    if (scans >= 50) return "Advanced";
    if (scans >= 20) return "Intermediate";
    return "Beginner";
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl min-h-screen flex flex-col">
      <div className="grid gap-8 flex-1">
        {/* Profile Overview */}
        <Card className="border-0 shadow-xl rounded-2xl overflow-hidden">
          <div className="h-32 bg-gradient-to-r from-blue-500 to-purple-600"></div>
          <CardHeader className="relative pt-0">
            <div className="flex flex-col md:flex-row md:items-end gap-6 -mt-12">
              <div className="w-24 h-24 rounded-xl bg-white p-1 shadow-lg">
                <div className="w-full h-full rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                  <span className="text-3xl font-semibold text-white">
                    {user.full_name?.[0] || user.email[0].toUpperCase()}
                  </span>
                </div>
              </div>
              <div className="flex-1">
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
                  {user.full_name || "FakeGuard User"}
                </h1>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mt-2">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-600">{user.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-600">
                      Joined {new Date(user.created_date).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
              <div className="relative group rounded-xl bg-gradient-to-r from-blue-50 to-blue-100 border border-blue-200 p-4 cursor-pointer hover:shadow-md transition-all overflow-hidden">
                <div className="absolute top-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <ArrowUpRight className="h-4 w-4 text-blue-400" />
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-md">
                    <Award className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">Expertise Level</div>
                    <div className="font-semibold text-gray-900 text-lg">
                      {getExpertiseLevel(profile?.total_scans || 0)}
                    </div>
                  </div>
                </div>
              </div>

              <div className="relative group rounded-xl bg-gradient-to-r from-green-50 to-green-100 border border-green-200 p-4 cursor-pointer hover:shadow-md transition-all overflow-hidden">
                <div className="absolute top-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <ArrowUpRight className="h-4 w-4 text-green-400" />
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center shadow-md">
                    <Scan className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">Total Scans</div>
                    <div className="font-semibold text-gray-900 text-lg">
                      {profile?.total_scans || 0}
                    </div>
                  </div>
                </div>
              </div>

              <div className="relative group rounded-xl bg-gradient-to-r from-purple-50 to-purple-100 border border-purple-200 p-4 cursor-pointer hover:shadow-md transition-all overflow-hidden">
                <div className="absolute top-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <ArrowUpRight className="h-4 w-4 text-purple-400" />
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center shadow-md">
                    <Shield className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">Fakes Detected</div>
                    <div className="font-semibold text-gray-900 text-lg">
                      {profile?.successful_detections || 0}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Activity & Achievements */}
        <div className="grid md:grid-cols-2 gap-8">
          <Card className="border-0 shadow-md rounded-xl overflow-hidden">
            <CardHeader className="border-b bg-gradient-to-r from-gray-50 to-gray-100">
              <h2 className="text-xl font-semibold">Recent Activity</h2>
            </CardHeader>
            <CardContent className="p-6">
              {profile?.last_scan_date ? (
                <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-xl">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Last scan completed</div>
                    <div className="font-medium">{new Date(profile.last_scan_date).toLocaleString()}</div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Scan className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <div>No recent activity</div>
                  <div className="text-sm text-gray-400 mt-1">Try scanning a product</div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md rounded-xl overflow-hidden">
            <CardHeader className="border-b bg-gradient-to-r from-gray-50 to-gray-100">
              <h2 className="text-xl font-semibold">Achievements</h2>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                {profile?.total_scans >= 10 && (
                  <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                      <Award className="w-4 h-4 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">Scanner Pro</div>
                      <div className="text-sm text-gray-500">Completed 10+ product scans</div>
                    </div>
                    <Badge className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0">10+</Badge>
                  </div>
                )}
                
                {profile?.successful_detections >= 5 && (
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                      <Shield className="w-4 h-4 text-purple-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">Guardian</div>
                      <div className="text-sm text-gray-500">Identified 5+ counterfeit products</div>
                    </div>
                    <Badge className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0">5+</Badge>
                  </div>
                )}
                
                {(!profile?.total_scans || profile.total_scans < 10) && (
                  <div className="text-center py-8 text-gray-500">
                    <Award className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                    <div>Complete more scans to earn achievements!</div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-4"
                      onClick={() => window.location.href = createPageUrl("Scanner")}
                    >
                      Start Scanning
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
