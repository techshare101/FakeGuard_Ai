
import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { SendEmail } from "@/api/integrations";
import { User } from "@/api/entities";
import { UserProfile } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { CheckCircle, ShoppingCart, CreditCard, Zap, Infinity, Scan, Lock } from "lucide-react";
import Footer from "../components/legal/Footer";
import StripeIntegration from "@/api/integrations";

export default function Pricing() {
  const [selectedPlan, setSelectedPlan] = useState("subscription");
  const [scanCount, setScanCount] = useState(5);
  const [loading, setLoading] = useState(false);
  const [hasActiveSubscription, setHasActiveSubscription] = useState(false);
  const [initialPlan, setInitialPlan] = useState("subscription");
  
  useEffect(() => {
    checkExistingSubscription();
    
    const urlParams = new URLSearchParams(window.location.search);
    const recommended = urlParams.get('recommended');
    if (recommended === 'subscription') {
      setSelectedPlan('subscription');
    } else if (recommended === 'payPerScan') {
      setSelectedPlan('payPerScan');
    }
  }, []);

  const checkExistingSubscription = async () => {
    try {
      const user = await User.me();
      console.log("Checking subscription for user:", user.email);
      
      const userProfiles = await UserProfile.filter({ created_by: user.email });
      console.log("Found profiles:", userProfiles.length);
      
      if (userProfiles.length > 0) {
        const profile = userProfiles[0];
        console.log("User profile:", profile);
        
        if (profile.subscription_active || (profile.available_scans && profile.available_scans > 0)) {
          console.log("User has active subscription or available scans");
          setHasActiveSubscription(true);
        }
      }
    } catch (error) {
      console.log("Not authenticated or error checking subscription:", error);
    }
  };

  const handleProceedToCheckout = async () => {
    setLoading(true);
    try {
      const successUrl = `${window.location.origin}${createPageUrl("PaymentSuccess")}?plan=${selectedPlan}&scanCount=${scanCount}`;
      const cancelUrl = `${window.location.origin}${createPageUrl("Pricing")}`;

      let checkoutSession;
      
      if (selectedPlan === "subscription") {
        checkoutSession = await StripeIntegration.create_checkout_session({
          success_url: successUrl,
          cancel_url: cancelUrl,
          price_data: {
            currency: 'usd',
            unit_amount: 999,
            recurring: {
              interval: 'month'
            },
            product_data: {
              name: 'FakeGuard AI Monthly Subscription',
              description: 'Unlimited product authenticity scans',
              images: ['https://images.unsplash.com/photo-1635376762252-41cf874ed357?w=800&auto=format&fit=crop']
            }
          }
        });
      } else {
        const scanPackages = {
          5: { amount: 495, total: 4.95, perScan: 0.99 },
          10: { amount: 990, total: 9.90, perScan: 0.99 },
          20: { amount: 1780, total: 17.80, perScan: 0.89 },
          50: { amount: 3950, total: 39.50, perScan: 0.79 }
        };

        const selectedPackage = scanPackages[scanCount];
        checkoutSession = await StripeIntegration.create_checkout_session({
          success_url: successUrl,
          cancel_url: cancelUrl,
          price_data: {
            currency: 'usd',
            unit_amount: selectedPackage.amount,
            product_data: {
              name: `FakeGuard AI - ${scanCount} Scans Package`,
              description: `Package of ${scanCount} product authenticity scans ($${selectedPackage.total} total, $${selectedPackage.perScan}/scan)`,
              images: ['https://images.unsplash.com/photo-1635376762252-41cf874ed357?w=800&auto=format&fit=crop']
            }
          }
        });
      }

      window.location.href = checkoutSession.url;
    } catch (error) {
      console.error("Checkout error:", error);
      alert("There was an error initiating checkout. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (hasActiveSubscription) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-md min-h-screen flex flex-col items-center justify-center">
        <Card className="p-8 shadow-xl border-0 rounded-2xl w-full">
          <div className="text-center mb-6">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">You're Already Subscribed!</h2>
            <p className="text-gray-600">
              You already have an active subscription or available scans. No need to purchase again.
            </p>
          </div>
          
          <div className="space-y-4">
            <Button 
              onClick={() => window.location.href = createPageUrl("Scanner")}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600"
            >
              <Scan className="mr-2 h-5 w-5" />
              Go to Scanner
            </Button>
            
            <Button 
              variant="outline"
              onClick={() => window.location.href = createPageUrl("Dashboard")}
              className="w-full"
            >
              View Dashboard
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  const scanPackages = [
    { scans: 5, pricePerScan: 0.99, total: 4.95 },
    { scans: 10, pricePerScan: 0.99, total: 9.90 },
    { scans: 20, pricePerScan: 0.89, total: 17.80, discount: "10%" },
    { scans: 50, pricePerScan: 0.79, total: 39.50, discount: "20%" }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl min-h-screen flex flex-col">
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
          Choose Your Plan
        </h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Select the payment option that works best for you and start protecting yourself from counterfeit products
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-12">
        <Card className={`relative overflow-hidden border-2 p-6 rounded-xl transition-all duration-300 ${
          selectedPlan === "subscription" ? "border-blue-500 shadow-lg shadow-blue-100" : "border-gray-200"
        }`}>
          {selectedPlan === "subscription" && (
            <div className="absolute top-0 right-0">
              <div className="bg-blue-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                SELECTED
              </div>
            </div>
          )}
          
          {initialPlan === "subscription" && (
            <div className="absolute top-0 left-0">
              <div className="bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-br-lg">
                RECOMMENDED
              </div>
            </div>
          )}
          
          <div className="flex justify-between items-start mb-6">
            <div>
              <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                <Infinity className="w-5 h-5 text-blue-500" />
                Unlimited Subscription
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                Perfect for regular users seeking unlimited protection
              </p>
            </div>
            <RadioGroup value={selectedPlan} onValueChange={setSelectedPlan}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="subscription" id="subscription" />
                <Label htmlFor="subscription"></Label>
              </div>
            </RadioGroup>
          </div>
          
          <div className="mb-6">
            <span className="text-3xl font-bold text-gray-900">$9.99</span>
            <span className="text-gray-600 ml-1">/month</span>
            <p className="text-sm text-gray-500 mt-1">Cancel anytime</p>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-4 mb-6">
            <h4 className="font-medium text-gray-900 mb-3">What's included:</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-500 flex-shrink-0" />
                <span className="text-gray-700">Unlimited product scans</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-500 flex-shrink-0" />
                <span className="text-gray-700">Priority analysis processing</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-500 flex-shrink-0" />
                <span className="text-gray-700">Detailed authenticity reports</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-500 flex-shrink-0" />
                <span className="text-gray-700">Scan history and analytics</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-500 flex-shrink-0" />
                <span className="text-gray-700">Premium customer support</span>
              </li>
            </ul>
          </div>
          
          <Button 
            className={`w-full py-6 rounded-xl ${
              selectedPlan === "subscription" 
                ? "bg-gradient-to-r from-blue-600 to-purple-600" 
                : "bg-gray-100 text-gray-800 hover:bg-gray-200"
            }`}
            onClick={() => setSelectedPlan("subscription")}
          >
            {selectedPlan === "subscription" ? (
              <span className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Best Value
              </span>
            ) : "Select Plan"}
          </Button>
        </Card>

        <Card className={`relative overflow-hidden border-2 p-6 rounded-xl transition-all duration-300 ${
          selectedPlan === "payPerScan" ? "border-purple-500 shadow-lg shadow-purple-100" : "border-gray-200"
        }`}>
          {selectedPlan === "payPerScan" && (
            <div className="absolute top-0 right-0">
              <div className="bg-purple-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                SELECTED
              </div>
            </div>
          )}
          
          <div className="flex justify-between items-start mb-6">
            <div>
              <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                <Zap className="w-5 h-5 text-purple-500" />
                Pay-Per-Scan Packages
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                Flexible pricing with volume discounts
              </p>
            </div>
            <RadioGroup value={selectedPlan} onValueChange={setSelectedPlan}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="payPerScan" id="payPerScan" />
                <Label htmlFor="payPerScan"></Label>
              </div>
            </RadioGroup>
          </div>

          {selectedPlan === "payPerScan" && (
            <div className="mb-6">
              <div className="grid grid-cols-2 gap-3">
                {scanPackages.map((pkg) => (
                  <button
                    key={pkg.scans}
                    onClick={() => setScanCount(pkg.scans)}
                    className={`relative p-4 rounded-xl border-2 transition-all ${
                      scanCount === pkg.scans 
                        ? "border-purple-500 bg-purple-50" 
                        : "border-gray-200 hover:border-purple-200"
                    }`}
                  >
                    {pkg.discount && (
                      <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                        Save {pkg.discount}
                      </div>
                    )}
                    <div className="text-lg font-bold text-gray-900">{pkg.scans} Scans</div>
                    <div className="text-sm text-gray-600">${pkg.pricePerScan}/scan</div>
                    <div className="text-purple-600 font-semibold mt-1">
                      Total: ${pkg.total}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
          
          <div className="bg-purple-50 rounded-lg p-4 mb-6">
            <h4 className="font-medium text-gray-900 mb-3">What's included:</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-500 flex-shrink-0" />
                <span className="text-gray-700">Pay only for what you use</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-500 flex-shrink-0" />
                <span className="text-gray-700">Same accurate AI analysis</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-500 flex-shrink-0" />
                <span className="text-gray-700">Save scans for future use</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-500 flex-shrink-0" />
                <span className="text-gray-700">Basic scan history</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-500 flex-shrink-0" />
                <span className="text-gray-700">Standard customer support</span>
              </li>
            </ul>
          </div>
          
          <Button 
            className={`w-full py-6 rounded-xl ${
              selectedPlan === "payPerScan" 
                ? "bg-gradient-to-r from-purple-600 to-pink-600" 
                : "bg-gray-100 text-gray-800 hover:bg-gray-200"
            }`}
            onClick={() => setSelectedPlan("payPerScan")}
          >
            {selectedPlan === "payPerScan" ? (
              <span className="flex items-center gap-2">
                <Scan className="w-5 h-5" />
                Flexible Option
              </span>
            ) : "Select Plan"}
          </Button>
        </Card>
      </div>

      <div className="text-center">
        <Button
          size="lg"
          className="bg-gray-900 hover:bg-gray-800 text-white px-8 py-6 rounded-xl font-medium text-lg"
          onClick={handleProceedToCheckout}
          disabled={loading}
        >
          {loading ? (
            <span className="flex items-center gap-2">
              Processing...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5" />
              Proceed to Checkout
            </span>
          )}
        </Button>
        
        <div className="flex items-center justify-center gap-2 mt-4 text-gray-500 text-sm">
          <Lock className="w-4 h-4" />
          <span>Secure checkout process • Cancel anytime</span>
        </div>
      </div>
      
      <div className="mt-16 bg-gray-50 rounded-xl p-6 border border-gray-200">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-gray-900 mb-2">How does billing work?</h4>
            <p className="text-gray-600 text-sm">
              For the subscription plan, you'll be billed monthly. For pay-per-scan, you purchase a pack of scans that don't expire.
            </p>
          </div>
          <div>
            <h4 className="font-medium text-gray-900 mb-2">Can I cancel my subscription?</h4>
            <p className="text-gray-600 text-sm">
              Yes, you can cancel your subscription at any time. Your access will continue until the end of your current billing period.
            </p>
          </div>
          <div>
            <h4 className="font-medium text-gray-900 mb-2">Do my pay-per-scan credits expire?</h4>
            <p className="text-gray-600 text-sm">
              No, once purchased, your scan credits remain in your account until used.
            </p>
          </div>
          <div>
            <h4 className="font-medium text-gray-900 mb-2">Is there a free trial?</h4>
            <p className="text-gray-600 text-sm">
              New users get 3 free scans to try our service before committing to a plan.
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
