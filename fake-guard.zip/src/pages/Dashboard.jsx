
import React, { useState, useEffect } from "react";
import { ScanResult } from "@/api/entities";
import { UserProfile } from "@/api/entities";
import { User } from "@/api/entities";
import { BarChart, Search, Filter, Clock, Calendar, ArrowUpRight, CheckCircle, AlertTriangle, XCircle, Camera, Trash2, Loader2 } from "lucide-react";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { createPageUrl } from "@/utils";
import StatsOverview from "../components/dashboard/StatsOverview";
import TrendAnalysis from "../components/dashboard/TrendAnalysis";
import ScanResultDetails from "../components/scanner/ScanResultDetails";
import Footer from "../components/legal/Footer";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Dashboard() {
  const [scanResults, setScanResults] = useState([]);
  const [userProfile, setUserProfile] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedScan, setSelectedScan] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [scanToDelete, setScanToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [user, results] = await Promise.all([
        User.me(),
        ScanResult.filter({}, "-created_date", 100)
      ]);
      
      setScanResults(results);

      const profiles = await UserProfile.filter({ created_by: user.email });
      if (profiles.length > 0) {
        setUserProfile(profiles[0]);
      }
    } catch (error) {
      console.error("Error loading dashboard:", error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleScanSelect = (scan) => {
    setSelectedScan(scan);
  };
  
  const handleDeleteScan = async (scanId) => {
    try {
      setIsDeleting(true);
      await ScanResult.delete(scanId);
      
      setScanResults(prev => prev.filter(scan => scan.id !== scanId));
      
      if (selectedScan && selectedScan.id === scanId) {
        setSelectedScan(null);
      }
      
      setScanToDelete(null);
    } catch (error) {
      console.error("Error deleting scan:", error);
      alert("Failed to delete scan. Please try again.");
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredScans = scanResults.filter(scan => {
    const matchesType = filterType === "all" || scan.result === filterType;
    if (!searchTerm) return matchesType;
    const searchLower = searchTerm.toLowerCase();
    const dateStr = new Date(scan.created_date).toLocaleDateString();
    return matchesType && (
      dateStr.includes(searchLower) || 
      scan.confidence_score.toString().includes(searchLower)
    );
  });
  
  const resultConfig = {
    authentic: {
      icon: CheckCircle,
      color: "text-green-600",
      badge: "bg-green-100 text-green-800"
    },
    suspicious: {
      icon: AlertTriangle,
      color: "text-yellow-600",
      badge: "bg-yellow-100 text-yellow-800"
    },
    fake: {
      icon: XCircle,
      color: "text-red-600",
      badge: "bg-red-100 text-red-800"
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 min-h-screen flex flex-col">
      <div className="mb-8 flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
          <BarChart className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Analysis Dashboard</h1>
          <p className="text-gray-600">Track and analyze your product authenticity scans</p>
        </div>
      </div>

      <div className="space-y-8 flex-1">
        <StatsOverview 
          scanResults={scanResults} 
          userProfile={userProfile} 
          isLoading={isLoading} 
        />
        
        <div className="grid lg:grid-cols-2 gap-8">
          <TrendAnalysis scanResults={scanResults} isLoading={isLoading} />
          
          <Card className="border-0 shadow-md rounded-xl overflow-hidden">
            <CardHeader className="border-b bg-gradient-to-r from-gray-50 to-gray-100">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">Scan History</h2>
                <Clock className="h-5 w-5 text-gray-400" />
              </div>
            </CardHeader>
            
            <div className="p-4 border-b">
              <div className="flex flex-wrap gap-3">
                <div className="flex-1 min-w-[180px]">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search scans..."
                      className="pl-9"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Filter by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Results</SelectItem>
                    <SelectItem value="authentic">Authentic</SelectItem>
                    <SelectItem value="suspicious">Suspicious</SelectItem>
                    <SelectItem value="fake">Counterfeit</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <CardContent className="p-0 max-h-[400px] overflow-y-auto">
              <div className="divide-y">
                {isLoading ? (
                  Array(5).fill().map((_, i) => (
                    <div key={i} className="flex items-center gap-4 p-4">
                      <div className="w-16 h-16 bg-gray-100 rounded-lg animate-pulse"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-gray-100 rounded w-24 mb-2 animate-pulse"></div>
                        <div className="h-3 bg-gray-100 rounded w-32 animate-pulse"></div>
                      </div>
                    </div>
                  ))
                ) : filteredScans.length > 0 ? (
                  filteredScans.map((scan) => {
                    const config = resultConfig[scan.result];
                    const ResultIcon = config.icon;
                    const scanDate = new Date(scan.created_date);

                    return (
                      <div
                        key={scan.id}
                        className="flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors group"
                      >
                        <div 
                          className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100 cursor-pointer"
                          onClick={() => handleScanSelect(scan)}
                        >
                          <img
                            src={scan.image_url}
                            alt="Scanned product"
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div 
                          className="flex-1 min-w-0 cursor-pointer"
                          onClick={() => handleScanSelect(scan)}
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <ResultIcon className={`w-4 h-4 ${config.color}`} />
                            <div className={`text-xs px-2 py-0.5 rounded-full ${config.badge}`}>
                              {scan.result.charAt(0).toUpperCase() + scan.result.slice(1)}
                            </div>
                            <span className="text-sm text-gray-500">
                              {scan.confidence_score}% confidence
                            </span>
                          </div>
                          <div className="text-sm text-gray-600 flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-gray-400" />
                            {scanDate.toLocaleDateString()} {scanDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={(e) => {
                              e.stopPropagation();
                              setScanToDelete(scan);
                            }}
                          >
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleScanSelect(scan)}
                          >
                            <ArrowUpRight className="w-4 h-4 text-gray-400" />
                          </Button>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <div className="w-16 h-16 mx-auto rounded-full bg-gray-100 flex items-center justify-center mb-3">
                      <Filter className="w-6 h-6 text-gray-400" />
                    </div>
                    <p>No scan results match your filters</p>
                    <Button 
                      variant="link" 
                      onClick={() => {
                        setSearchTerm("");
                        setFilterType("all");
                      }}
                    >
                      Clear filters
                    </Button>
                  </div>
                )}
                
                {filteredScans.length === 0 && scanResults.length === 0 && !isLoading && (
                  <div className="text-center py-12 text-gray-500">
                    <div className="w-16 h-16 mx-auto rounded-full bg-gray-100 flex items-center justify-center mb-3">
                      <Camera className="w-6 h-6 text-gray-400" />
                    </div>
                    <p>No scan history available</p>
                    <p className="text-sm text-gray-400 mt-1">Scan a product to get started</p>
                    <Button 
                      variant="outline"
                      className="mt-4"
                      onClick={() => window.location.href = createPageUrl("Scanner")}
                    >
                      Go to Scanner
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {selectedScan && (
        <ScanResultDetails
          result={selectedScan}
          isOpen={!!selectedScan}
          onClose={() => setSelectedScan(null)}
        />
      )}
      
      <AlertDialog open={!!scanToDelete} onOpenChange={(open) => !open && setScanToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Scan</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this scan? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => scanToDelete && handleDeleteScan(scanToDelete.id)}
              disabled={isDeleting}
              className="bg-red-500 hover:bg-red-600 text-white"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <Footer />
    </div>
  );
}
