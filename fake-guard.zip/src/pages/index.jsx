import Layout from "./Layout.jsx";

import Scanner from "./Scanner";

import Dashboard from "./Dashboard";

import Profile from "./Profile";

import OrderPayment from "./OrderPayment";

import Pricing from "./Pricing";

import PaymentSuccess from "./PaymentSuccess";

import StripeWebhook from "./StripeWebhook";

import Subscription from "./Subscription";

import Contact from "./Contact";

import TestingGuide from "./TestingGuide";

import manifest from "./manifest";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Scanner: Scanner,
    
    Dashboard: Dashboard,
    
    Profile: Profile,
    
    OrderPayment: OrderPayment,
    
    Pricing: Pricing,
    
    PaymentSuccess: PaymentSuccess,
    
    StripeWebhook: StripeWebhook,
    
    Subscription: Subscription,
    
    Contact: Contact,
    
    TestingGuide: TestingGuide,
    
    manifest: manifest,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Scanner />} />
                
                
                <Route path="/Scanner" element={<Scanner />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/OrderPayment" element={<OrderPayment />} />
                
                <Route path="/Pricing" element={<Pricing />} />
                
                <Route path="/PaymentSuccess" element={<PaymentSuccess />} />
                
                <Route path="/StripeWebhook" element={<StripeWebhook />} />
                
                <Route path="/Subscription" element={<Subscription />} />
                
                <Route path="/Contact" element={<Contact />} />
                
                <Route path="/TestingGuide" element={<TestingGuide />} />
                
                <Route path="/manifest" element={<manifest />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}