
import React, { useEffect, useState } from 'react';
import { User } from "@/api/entities";
import { UserProfile } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle, ArrowRight, Scan } from "lucide-react";

export default function PaymentSuccess() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const activateSubscription = async () => {
      try {
        const urlParams = new URLSearchParams(window.location.search);
        const plan = urlParams.get('plan');
        const scanCount = urlParams.get('scanCount');
        
        const user = await User.me();
        const userProfiles = await UserProfile.filter({ created_by: user.email });
        
        if (userProfiles.length > 0) {
          const profile = userProfiles[0];
          
          if (plan === 'subscription') {
            await UserProfile.update(profile.id, {
              subscription_active: true,
              subscription_end_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
              payment_status: "paid"
            });
          } else {
            await UserProfile.update(profile.id, {
              available_scans: (profile.available_scans || 0) + parseInt(scanCount),
              payment_status: "paid"
            });
          }
        } else {
          await UserProfile.create({
            subscription_active: plan === 'subscription',
            subscription_end_date: plan === 'subscription' ? 
              new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() : null,
            available_scans: plan === 'subscription' ? 0 : parseInt(scanCount),
            payment_status: "paid",
            total_scans: 0,
            successful_detections: 0
          });
        }

        setTimeout(() => {
          window.location.href = createPageUrl("Scanner");
        }, 3000);
      } catch (error) {
        console.error("Error activating subscription:", error);
        setError("Failed to activate your subscription. Please contact support.");
      } finally {
        setLoading(false);
      }
    };

    activateSubscription();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-md">
        <Card className="p-6 text-center">
          <div className="text-red-500 mb-4">⚠️</div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Payment Error</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <Button onClick={() => window.location.href = createPageUrl("Pricing")}>
            Try Again
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16 max-w-md">
      <Card className="p-8 text-center">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-8 h-8 text-green-600" />
        </div>
        
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          Payment Successful!
        </h1>
        
        <p className="text-gray-600 mb-6">
          Your FakeGuard AI subscription has been activated. You can now start scanning products.
        </p>
        
        <div className="space-y-3">
          <Button 
            onClick={() => window.location.href = createPageUrl("Scanner")}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600"
          >
            <Scan className="mr-2 h-5 w-5" />
            Start Scanning
          </Button>
          
          <Button 
            onClick={() => window.location.href = createPageUrl("Dashboard")}
            variant="outline"
            className="w-full"
          >
            View Dashboard
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </Card>
    </div>
  );
}
