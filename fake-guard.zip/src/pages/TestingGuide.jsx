import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { createPageUrl } from "@/utils";
import { CheckCircle, Camera, LayoutDashboard, ShoppingCart, UserCircle, Shield } from "lucide-react";
import Footer from "../components/legal/Footer";

export default function TestingGuide() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl min-h-screen flex flex-col">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">FakeGuard AI Testing Guide</h1>
        <p className="text-gray-600">Follow these steps to test the complete flow of the application</p>
      </div>

      <Tabs defaultValue="scanner" className="flex-1 mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="scanner" className="flex items-center gap-2">
            <Camera className="h-4 w-4" />
            Scanner
          </TabsTrigger>
          <TabsTrigger value="account" className="flex items-center gap-2">
            <UserCircle className="h-4 w-4" />
            Account
          </TabsTrigger>
          <TabsTrigger value="subscription" className="flex items-center gap-2">
            <ShoppingCart className="h-4 w-4" />
            Subscription
          </TabsTrigger>
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <LayoutDashboard className="h-4 w-4" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="e2e" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Complete Flow
          </TabsTrigger>
        </TabsList>

        <TabsContent value="scanner" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Testing the Scanner</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Login Flow
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Navigate to the Scanner page</li>
                  <li>Click on "Take Photo" or "Upload Image" when not logged in</li>
                  <li>You should be prompted to sign in</li>
                  <li>After signing in, verify you're redirected back to the Scanner</li>
                </ol>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Camera Functionality
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Click "Take Photo" button</li>
                  <li>Confirm the rear camera activates (for mobile devices)</li>
                  <li>Test camera switch button if available</li>
                  <li>Take a photo of any product</li>
                  <li>Confirm you're shown a preview of the captured image</li>
                </ol>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Upload Functionality
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Click "Upload Image" button</li>
                  <li>Select an image from your device</li>
                  <li>Verify scanning animation displays</li>
                  <li>Confirm results are shown after processing</li>
                </ol>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Results Display
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Verify the scan result shows (Authentic, Suspicious, or Fake)</li>
                  <li>Confirm confidence score and detailed analysis is visible</li>
                  <li>Test the share and download functionality</li>
                  <li>Click "Scan Another" to return to scanner</li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="account" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Testing User Account</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Profile Page
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Navigate to the Profile page</li>
                  <li>Verify your user information is displayed correctly</li>
                  <li>Check that scan statistics (total scans, fakes detected) are visible</li>
                  <li>Confirm achievements are shown based on your activity</li>
                </ol>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Navigation
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Verify sidebar navigation works on all pages</li>
                  <li>Test that mobile menu opens and closes correctly</li>
                  <li>Confirm logout functionality works</li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="subscription" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Testing Subscription Flow</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Pricing Page
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Navigate to the Pricing page</li>
                  <li>Toggle between subscription and pay-per-scan options</li>
                  <li>Select different scan packages if choosing pay-per-scan</li>
                  <li>Click "Proceed to Checkout"</li>
                  <li>Verify redirect to payment page</li>
                </ol>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Subscription Management
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Navigate to the Subscription page</li>
                  <li>Verify subscription details are displayed correctly</li>
                  <li>Click "Manage Subscription" if you have an active subscription</li>
                  <li>Confirm cancel and update payment options work</li>
                </ol>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Payment Success
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Complete a test payment (using test card details)</li>
                  <li>Verify redirect to payment success page</li>
                  <li>Confirm subscription status updates in your profile</li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="dashboard" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Testing Dashboard Functionality</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Stats Overview
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Navigate to the Dashboard page</li>
                  <li>Verify stats cards show correct scan counts</li>
                  <li>Check that trend analysis graph displays scan history</li>
                </ol>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Scan History
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Verify scan history list shows your previous scans</li>
                  <li>Test the search functionality</li>
                  <li>Use the filter dropdown to filter by result type</li>
                  <li>Click on a scan to view details</li>
                </ol>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Scan Management
                </h3>
                <ol className="list-decimal ml-6 space-y-1 text-gray-700">
                  <li>Hover over a scan to reveal the delete button</li>
                  <li>Click the delete button to open confirmation dialog</li>
                  <li>Confirm deletion and verify scan is removed from list</li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="e2e" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>End-to-End Testing Flow</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-lg mb-4">
                <p className="text-blue-700 text-sm italic">
                  Follow this sequence to test the complete user journey through the application
                </p>
              </div>

              <ol className="list-decimal ml-6 space-y-3 text-gray-700">
                <li className="font-medium">
                  <span className="text-blue-700">Sign Up / Login</span>
                  <ul className="list-disc ml-6 mt-1 font-normal">
                    <li>Open the Scanner page</li>
                    <li>Click on "Sign In to Continue"</li>
                    <li>Complete the login process</li>
                  </ul>
                </li>

                <li className="font-medium">
                  <span className="text-blue-700">Purchase a Subscription</span>
                  <ul className="list-disc ml-6 mt-1 font-normal">
                    <li>Navigate to the Pricing page</li>
                    <li>Select either subscription or pay-per-scan</li>
                    <li>Complete the checkout process</li>
                    <li>Verify successful payment</li>
                  </ul>
                </li>

                <li className="font-medium">
                  <span className="text-blue-700">Scan a Product</span>
                  <ul className="list-disc ml-6 mt-1 font-normal">
                    <li>Navigate to the Scanner page</li>
                    <li>Choose camera or upload option</li>
                    <li>Scan a product</li>
                    <li>Review the scan results</li>
                    <li>Share or download the result</li>
                  </ul>
                </li>

                <li className="font-medium">
                  <span className="text-blue-700">Check Dashboard</span>
                  <ul className="list-disc ml-6 mt-1 font-normal">
                    <li>Go to the Dashboard</li>
                    <li>Verify your scan appears in history</li>
                    <li>Check that statistics have updated</li>
                    <li>Test filters and search</li>
                    <li>View scan details by clicking on it</li>
                  </ul>
                </li>

                <li className="font-medium">
                  <span className="text-blue-700">Manage Subscription</span>
                  <ul className="list-disc ml-6 mt-1 font-normal">
                    <li>Go to the Subscription page</li>
                    <li>Click "Manage Subscription"</li>
                    <li>Test the update and cancel options</li>
                  </ul>
                </li>

                <li className="font-medium">
                  <span className="text-blue-700">Review Profile</span>
                  <ul className="list-disc ml-6 mt-1 font-normal">
                    <li>Navigate to Profile page</li>
                    <li>Verify scan stats and achievements</li>
                    <li>Check user information is correct</li>
                  </ul>
                </li>

                <li className="font-medium">
                  <span className="text-blue-700">Delete a Scan</span>
                  <ul className="list-disc ml-6 mt-1 font-normal">
                    <li>Return to Dashboard</li>
                    <li>Hover over a scan and click the delete button</li>
                    <li>Confirm deletion</li>
                    <li>Verify scan is removed from history</li>
                  </ul>
                </li>

                <li className="font-medium">
                  <span className="text-blue-700">Logout Test</span>
                  <ul className="list-disc ml-6 mt-1 font-normal">
                    <li>Click the logout button in the sidebar</li>
                    <li>Verify you're redirected to the Scanner page</li>
                    <li>Confirm protected pages require login</li>
                  </ul>
                </li>
              </ol>

              <div className="mt-6 p-4 bg-amber-50 rounded-lg">
                <h3 className="font-semibold text-amber-800 mb-2">Test Card Details</h3>
                <p className="text-sm text-amber-700 mb-2">
                  For testing payments, use these Stripe test card details:
                </p>
                <ul className="list-disc ml-6 text-sm text-amber-700">
                  <li>Card Number: 4242 4242 4242 4242</li>
                  <li>Expiry: Any future date (MM/YY)</li>
                  <li>CVC: Any 3 digits</li>
                  <li>ZIP: Any 5 digits</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Footer />
    </div>
  );
}