
import React, { useState } from "react";
import { 
  Card, 
  CardHeader, 
  CardContent, 
  CardFooter,
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Mail, 
  MessageSquare, 
  MapPin, 
  Send, 
  CheckCircle,
  Shield,
  ArrowRight,
  AtSign 
} from "lucide-react";
import { SendEmail } from "@/api/integrations";
import { User } from "@/api/entities";
import Footer from "../components/legal/Footer";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [formStatus, setFormStatus] = useState({
    isSubmitting: false,
    isSubmitted: false,
    error: null
  });

  React.useEffect(() => {
    const loadUserData = async () => {
      try {
        const user = await User.me();
        if (user) {
          setFormData(prev => ({
            ...prev,
            name: user.full_name || "",
            email: user.email || ""
          }));
        }
      } catch (error) {
      }
    };
    
    loadUserData();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormStatus({
      isSubmitting: true,
      isSubmitted: false,
      error: null
    });

    try {
      if (!formData.name || !formData.email || !formData.message) {
        throw new Error("Please fill out all required fields");
      }

      await SendEmail({
        to: "infofakeguard@gmail.com",
        subject: `Contact Form: ${formData.subject || "General Inquiry"}`,
        body: `
          Name: ${formData.name}
          Email: ${formData.email}
          Subject: ${formData.subject || "General Inquiry"}
          
          Message:
          ${formData.message}
        `
      });

      setFormStatus({
        isSubmitting: false,
        isSubmitted: true,
        error: null
      });
      
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: ""
      });
    } catch (error) {
      setFormStatus({
        isSubmitting: false,
        isSubmitted: false,
        error: error.message
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl min-h-screen flex flex-col">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Contact Us</h1>
        <p className="text-gray-600">We're here to help with any questions or concerns</p>
      </div>

      <div className="grid md:grid-cols-5 gap-8 flex-1">
        <div className="md:col-span-3">
          <Card className="border-0 shadow-lg rounded-2xl overflow-hidden">
            <CardHeader className="pb-4">
              <CardTitle>Get in Touch</CardTitle>
              <CardDescription>
                Fill out the form below and our team will get back to you as soon as possible
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              {formStatus.isSubmitted ? (
                <div className="p-6 text-center">
                  <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-4">
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Message Sent!</h3>
                  <p className="text-gray-600 mb-4">
                    Thank you for reaching out. We'll respond to your inquiry as soon as possible.
                  </p>
                  <Button 
                    onClick={() => setFormStatus(prev => ({ ...prev, isSubmitted: false }))}
                    variant="outline"
                  >
                    Send Another Message
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid md:grid-cols-2 gap-5">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name<span className="text-red-500">*</span></Label>
                      <Input 
                        id="name"
                        name="name"
                        placeholder="Your name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address<span className="text-red-500">*</span></Label>
                      <Input 
                        id="email"
                        name="email"
                        type="email"
                        placeholder="Your email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input 
                      id="subject"
                      name="subject"
                      placeholder="What's this about?"
                      value={formData.subject}
                      onChange={handleChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="message">Message<span className="text-red-500">*</span></Label>
                    <Textarea 
                      id="message"
                      name="message"
                      placeholder="How can we help you?"
                      value={formData.message}
                      onChange={handleChange}
                      className="min-h-[150px]"
                      required
                    />
                  </div>
                  
                  {formStatus.error && (
                    <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm">
                      {formStatus.error}
                    </div>
                  )}
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600"
                    disabled={formStatus.isSubmitting}
                  >
                    {formStatus.isSubmitting ? (
                      <span className="flex items-center">
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Sending...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <Send className="w-4 h-4" />
                        Send Message
                      </span>
                    )}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2 space-y-6">
          <Card className="border-0 shadow-md rounded-2xl overflow-hidden">
            <CardHeader className="pb-2">
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                  <Mail className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Email Us</h3>
                  <p className="text-gray-600 mb-1">For general inquiries:</p>
                  <a href="mailto:infofakeguard@gmail.com" className="text-blue-600 hover:underline flex items-center gap-1">
                    <AtSign className="w-3 h-3" />
                    infofakeguard@gmail.com
                  </a>
                  <p className="text-gray-600 mt-2 mb-1">For support:</p>
                  <a href="mailto:infofakeguard@gmail.com" className="text-blue-600 hover:underline flex items-center gap-1">
                    <AtSign className="w-3 h-3" />
                    infofakeguard@gmail.com
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-md rounded-2xl overflow-hidden">
            <CardHeader className="pb-2">
              <CardTitle>Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1">
                <h3 className="font-medium text-gray-900">How accurate is the authentication?</h3>
                <p className="text-gray-600 text-sm">
                  FakeGuard AI uses advanced image recognition with 85-95% accuracy depending on product type and image quality.
                </p>
              </div>
              
              <div className="space-y-1">
                <h3 className="font-medium text-gray-900">How can I cancel my subscription?</h3>
                <p className="text-gray-600 text-sm">
                  You can cancel your subscription anytime from your Subscription page. Your access will remain until the end of your current billing period.
                </p>
              </div>
              
              <div className="space-y-1">
                <h3 className="font-medium text-gray-900">What products can be authenticated?</h3>
                <p className="text-gray-600 text-sm">
                  FakeGuard AI can analyze a wide range of products including luxury goods, electronics, clothing, and accessories.
                </p>
              </div>
              
              <Button 
                variant="link" 
                className="pl-0 text-blue-600 mt-2"
                onClick={() => alert("FAQ page coming soon")}
              >
                View All FAQs
                <ArrowRight className="ml-1 w-4 h-4" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Card className="my-8 border-0 shadow-md rounded-2xl overflow-hidden">
        <div className="grid md:grid-cols-2">
          <div className="p-8">
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="w-5 h-5 text-red-500" />
              <h3 className="text-xl font-semibold text-gray-900">Our Location</h3>
            </div>
            <p className="text-gray-600 mb-4">
              FakeGuard AI Headquarters<br />
              123 Tech Boulevard<br />
              Suite 456<br />
              San Francisco, CA 94107
            </p>
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-5 h-5 text-blue-600" />
                <h4 className="font-medium text-gray-900">Visit our office</h4>
              </div>
              <p className="text-gray-600 text-sm">
                Please note that all visits to our office must be scheduled in advance. Contact us to arrange a meeting with our team.
              </p>
            </div>
          </div>
          <div className="h-80 md:h-auto bg-gray-200">
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-r from-gray-100 to-gray-200">
              <div className="text-center">
                <MapPin className="w-12 h-12 mx-auto text-red-500 mb-2" />
                <p className="text-gray-600">Interactive map would be displayed here</p>
              </div>
            </div>
          </div>
        </div>
      </Card>
      
      <Footer />
    </div>
  );
}
