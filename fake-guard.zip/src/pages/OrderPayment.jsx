
import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { SendEmail } from "@/api/integrations";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { ShoppingCart, CheckCircle, AlertCircle, ExternalLink } from "lucide-react";
import OrderSuccess from "../components/orders/OrderSuccess";

export default function OrderPayment() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    orderNotes: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [error, setError] = useState("");
  const [planDetails, setPlanDetails] = useState({
    type: "subscription",
    scanCount: 5
  });
  const [debugInfo, setDebugInfo] = useState("");

  useEffect(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const plan = urlParams.get('plan');
      const scanCount = urlParams.get('scanCount');
      
      setDebugInfo(`URL params: plan=${plan}, scanCount=${scanCount}`);
      
      if (plan) {
        setPlanDetails({
          type: plan,
          scanCount: scanCount ? parseInt(scanCount) : 5
        });
      }
    } catch (error) {
      setDebugInfo(`Error parsing URL: ${error.message}`);
    }
  }, []);

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const user = await User.me();
        setFormData(prev => ({
          ...prev,
          fullName: user.full_name || "",
          email: user.email || ""
        }));
        setDebugInfo(prev => `${prev}\nUser loaded: ${user.email}`);
      } catch (error) {
        setDebugInfo(prev => `${prev}\nError loading user: ${error.message}`);
      }
    };
    
    loadUserData();
  }, []);

  const getPaymentLink = () => {
    const webhookUrl = "https://6a4a-97-116-96-110.ngrok-free.app/webhook/stripe";
    const baseUrl = window.location.origin;
    const successUrl = `${baseUrl}${createPageUrl("PaymentSuccess")}?plan=${planDetails.type}&scanCount=${planDetails.scanCount}`;
    
    let userEmailParam = '';
    if (formData.email) {
      userEmailParam = `&email=${encodeURIComponent(formData.email)}`;
    }
    
    if (planDetails.type === "subscription") {
      return `https://buy.stripe.com/bIYdTn8JG6bJ87u28b?success_url=${encodeURIComponent(successUrl)}&client_reference_id=${encodeURIComponent(formData.email)}&webhook_url=${encodeURIComponent(webhookUrl)}&plan_type=subscription${userEmailParam}`;
    } 
    
    const payPerScanLinks = {
      5: `https://buy.stripe.com/dR69D7e40arZ3Re4gk?success_url=${encodeURIComponent(successUrl)}&client_reference_id=${encodeURIComponent(formData.email)}&webhook_url=${encodeURIComponent(webhookUrl)}&plan_type=one_time&scan_count=5${userEmailParam}`,
      10: `https://buy.stripe.com/aEU4iN5xu9nV5Zm9AF?success_url=${encodeURIComponent(successUrl)}&client_reference_id=${encodeURIComponent(formData.email)}&webhook_url=${encodeURIComponent(webhookUrl)}&plan_type=one_time&scan_count=10${userEmailParam}`,
      20: `https://buy.stripe.com/your-20scan-link?success_url=${encodeURIComponent(successUrl)}&client_reference_id=${encodeURIComponent(formData.email)}&webhook_url=${encodeURIComponent(webhookUrl)}&plan_type=one_time&scan_count=20${userEmailParam}`,
      50: `https://buy.stripe.com/your-50scan-link?success_url=${encodeURIComponent(successUrl)}&client_reference_id=${encodeURIComponent(formData.email)}&webhook_url=${encodeURIComponent(webhookUrl)}&plan_type=one_time&scan_count=50${userEmailParam}`
    };
    
    return payPerScanLinks[planDetails.scanCount] || payPerScanLinks[5];
  };

  const getOrderSummary = () => {
    if (planDetails.type === "subscription") {
      return "Unlimited Scan Subscription Plan ($9.99/month)";
    } else {
      const packageInfo = {
        5: { price: 4.95, perScan: 0.99 },
        10: { price: 9.90, perScan: 0.99 },
        20: { price: 17.80, perScan: 0.89 },
        50: { price: 39.50, perScan: 0.79 }
      };
      
      const info = packageInfo[planDetails.scanCount] || packageInfo[5];
      return `Pay-Per-Scan Package (${planDetails.scanCount} scans at $${info.perScan} per scan = $${info.price})`;
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError("");
    setDebugInfo(prev => `${prev}\nSubmitting order...`);

    try {
      const user = await User.me();
      const orderSummary = getOrderSummary();
      const paymentLink = getPaymentLink();
      
      setDebugInfo(prev => `${prev}\nUser: ${user.email}\nOrder: ${orderSummary}\nPayment Link: ${paymentLink}`);
      
      try {
        await SendEmail({
          to: formData.email,
          subject: "Complete Your FakeGuard AI Purchase",
          body: `
Dear ${formData.fullName},

Thank you for your order with FakeGuard AI!

ORDER SUMMARY:
${orderSummary}

COMPLETE YOUR PURCHASE:
To activate your plan, please click the link below to complete your payment:

${paymentLink}

For test mode, use these card details:
Card Number: 4242 4242 4242 4242
Expiry: Any future date (e.g., 12/25)
CVC: Any 3 digits (e.g., 123)

Once your payment is processed, your account will be activated automatically.

If you have any questions or need assistance, please reply to this email.

Thank you for choosing FakeGuard AI for your product verification needs!

Best regards,
The FakeGuard AI Team
          `
        });
        
        setDebugInfo(prev => `${prev}\nCustomer email sent successfully`);
      } catch (emailError) {
        setDebugInfo(prev => `${prev}\nError sending customer email: ${emailError.message}`);
      }

      setShowSuccess(true);
    } catch (error) {
      setError("Failed to process your order. Please check the debugging information.");
      setDebugInfo(prev => `${prev}\nError: ${error.message}`);
      console.error("Order submission error:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDirectPayment = () => {
    window.open(getPaymentLink(), '_blank');
  };

  if (showSuccess) {
    return <OrderSuccess orderDetails={formData} paymentLink={getPaymentLink()} planDetails={planDetails} />;
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
          <ShoppingCart className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Complete Your Order</h1>
          <p className="text-gray-600">Enter your details to receive payment instructions</p>
        </div>
      </div>

      {error && (
        <Card className="p-4 mb-6 bg-red-50 border-red-200">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium text-red-800">Error Processing Order</h3>
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          </div>
        </Card>
      )}

      <Card className="p-6 border-0 shadow-lg rounded-xl mb-8">
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Order Summary</h2>
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
            <div className="font-medium">{getOrderSummary()}</div>
          </div>
        </div>

        <h2 className="text-xl font-semibold text-gray-900 mb-4">Contact Information</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
            <Input
              id="fullName"
              name="fullName"
              value={formData.fullName}
              onChange={handleInputChange}
              placeholder="Your full name"
              required
            />
          </div>
          
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
            <Input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleInputChange}
              placeholder="Your email address"
              required
            />
          </div>
          
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">Phone Number (Optional)</label>
            <Input
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleInputChange}
              placeholder="Your phone number"
            />
          </div>
          
          <div>
            <label htmlFor="orderNotes" className="block text-sm font-medium text-gray-700 mb-1">Order Notes (Optional)</label>
            <Textarea
              id="orderNotes"
              name="orderNotes"
              value={formData.orderNotes}
              onChange={handleInputChange}
              placeholder="Any specific requirements or questions"
              rows={3}
            />
          </div>
          
          <div className="pt-4 flex flex-col md:flex-row gap-4">
            <Button
              type="submit"
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-6 rounded-xl flex-1"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Processing..." : "Send Payment Instructions by Email"}
            </Button>
            
            <Button
              type="button"
              onClick={handleDirectPayment}
              className="bg-gray-800 hover:bg-gray-700 text-white py-6 rounded-xl flex-1"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Pay Directly Now
            </Button>
          </div>
        </form>
      </Card>
      
      <Card className="p-4 mb-6 border border-gray-200 bg-gray-50">
        <h3 className="font-medium text-gray-700 mb-2">Debug Information</h3>
        <pre className="text-xs bg-gray-100 p-3 rounded overflow-auto max-h-40">
          {debugInfo || "No debug information available"}
        </pre>
        <div className="mt-3 space-y-2">
          <h4 className="font-medium text-sm">Test Card Information:</h4>
          <div className="text-xs bg-white p-3 rounded border">
            <p>Card Number: 4242 4242 4242 4242</p>
            <p>Expiry: Any future date (e.g., 12/25)</p>
            <p>CVC: Any 3 digits (e.g., 123)</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
