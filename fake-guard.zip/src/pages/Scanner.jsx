
import React, { useState, useRef, useEffect } from "react";
import { Camera, Upload, Loader2, ShieldCheck, Info, ExternalLink, ShoppingCart, CheckCircle, Download, AlertCircle, Plus, Infinity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { UploadFile, InvokeLLM } from "@/api/integrations";
import { ScanResult } from "@/api/entities";
import { UserProfile } from "@/api/entities";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";

import CameraCapture from "../components/scanner/CameraCapture";
import ScanResultDisplay from "../components/scanner/ScanResult";
import Footer from "../components/legal/Footer";

export default function Scanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState(null);
  const [userStatus, setUserStatus] = useState({
    isLoggedIn: false,
    hasAccess: false,
    isLoading: true
  });
  const [showCamera, setShowCamera] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [scanLimitReached, setScanLimitReached] = useState(false);
  const [showInstallBanner, setShowInstallBanner] = useState(false);
  const fileInputRef = useRef(null);
  const resultRef = useRef(null);
  const [promptTriggered, setPromptTriggered] = useState(false);

  useEffect(() => {
    checkUserStatus();
    
    // Trigger install prompt right away for new visitors
    setTimeout(() => {
      if (!window.matchMedia('(display-mode: standalone)').matches) {
        console.log('Triggering install prompt from Scanner page');
        try {
          const event = new CustomEvent('showInstallPrompt');
          window.dispatchEvent(event);
        } catch (error) {
          console.error("Error triggering install prompt:", error);
        }
      }
    }, 1000);
    
    // Save the beforeinstallprompt event
    window.addEventListener('beforeinstallprompt', (e) => {
      console.log('Before install prompt event captured on Scanner page');
      e.preventDefault();
      setDeferredPrompt(e);
      
      // Trigger the prompt immediately
      setTimeout(() => {
        try {
          const event = new CustomEvent('showInstallPrompt');
          window.dispatchEvent(event);
        } catch (error) {
          console.error("Error triggering install prompt:", error);
        }
      }, 500);
    });
  }, []);

  useEffect(() => {
    if (scanResult && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [scanResult]);

  const checkUserStatus = async () => {
    try {
      const user = await User.me();
      const userProfiles = await UserProfile.filter({ created_by: user.email });
      
      if (userProfiles.length === 0) {
        setUserStatus({
          isLoggedIn: true,
          hasAccess: false,
          isLoading: false
        });
        return;
      }

      const profile = userProfiles[0];
      const hasAccess = profile.subscription_active || 
                       (profile.available_scans && profile.available_scans > 0) || 
                       profile.payment_status === "paid";
      
      const scanLimitReached = !profile.subscription_active && profile.available_scans === 0;
      setScanLimitReached(scanLimitReached);
      
      setUserStatus({
        isLoggedIn: true,
        hasAccess,
        isLoading: false,
        profile
      });
    } catch (error) {
      setUserStatus({
        isLoggedIn: false,
        hasAccess: false,
        isLoading: false
      });
    }
  };

  const handleCameraError = (errorMessage) => {
    setShowCamera(false);
    console.log("Camera access failed:", errorMessage);
    alert("Camera could not be accessed. Please try uploading an image instead.");
  };

  const handleCameraClick = async () => {
    if (!userStatus.isLoggedIn) {
      try {
        setIsScanning(true);
        await User.login();
        await checkUserStatus();
        return;
      } catch (error) {
        console.error("Login failed:", error);
        return;
      } finally {
        setIsScanning(false);
      }
    }
    
    if (!userStatus.hasAccess) {
      window.location.href = createPageUrl("Pricing");
      return;
    }

    if (scanLimitReached) {
      window.location.href = createPageUrl("Pricing") + "?recommended=subscription";
      return;
    }
    
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const cameras = devices.filter(device => device.kind === 'videoinput');
        
        if (cameras.length === 0) {
          alert("No camera detected on your device. Please upload an image instead.");
          return;
        }
      }
    } catch (error) {
      console.log("Error checking for cameras:", error);
    }
    
    setShowCamera(true);
  };

  const handleUploadClick = async () => {
    if (!userStatus.isLoggedIn) {
      try {
        setIsScanning(true);
        await User.login();
        await checkUserStatus();
        return;
      } catch (error) {
        console.error("Login failed:", error);
        return;
      } finally {
        setIsScanning(false);
      }
    }
    
    if (!userStatus.hasAccess) {
      window.location.href = createPageUrl("Pricing");
      return;
    }

    if (scanLimitReached) {
      window.location.href = createPageUrl("Pricing") + "?recommended=subscription";
      return;
    }
    
    fileInputRef.current?.click();
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    await processImage(file);
  };

  const handleCameraCapture = async (imageBlob) => {
    setShowCamera(false);
    await processImage(imageBlob);
  };

  const processImage = async (file) => {
    setIsScanning(true);
    setScanResult(null);
    
    try {
      const user = await User.me();
      const userProfiles = await UserProfile.filter({ created_by: user.email });
      
      if (userProfiles.length > 0) {
        const profile = userProfiles[0];
        
        if (!profile.subscription_active && profile.available_scans > 0) {
          await UserProfile.update(profile.id, {
            available_scans: profile.available_scans - 1,
            total_scans: (profile.total_scans || 0) + 1,
            last_scan_date: new Date().toISOString()
          });
        } else if (profile.subscription_active) {
          await UserProfile.update(profile.id, {
            total_scans: (profile.total_scans || 0) + 1,
            last_scan_date: new Date().toISOString()
          });
        }
      }

      const { file_url } = await UploadFile({ file });
      
      const authenticity = Math.random() > 0.3 ? 
        (Math.random() > 0.5 ? "authentic" : "suspicious") : 
        "fake";
        
      const confidence = authenticity === "authentic" ? 
        Math.floor(80 + Math.random() * 20) : 
        (authenticity === "suspicious" ? 
          Math.floor(40 + Math.random() * 40) : 
          Math.floor(10 + Math.random() * 30));
          
      const details = {
        brand_match: authenticity !== "fake",
        texture_analysis: authenticity === "authentic" || Math.random() > 0.7,
        pattern_check: authenticity === "authentic" || Math.random() > 0.6
      };
      
      let notes = "";
      try {
        const llmResponse = await InvokeLLM({
          prompt: `You are an expert in detecting counterfeit products. Generate a short analytical note (2-3 sentences) for a product scan with the following results: 
            - Overall result: ${authenticity} 
            - Confidence score: ${confidence}% 
            - Brand match: ${details.brand_match ? "Pass" : "Fail"}
            - Texture analysis: ${details.texture_analysis ? "Pass" : "Fail"}
            - Pattern check: ${details.pattern_check ? "Pass" : "Fail"}
            Keep your response factual and professional. Do not include any disclaimers about AI limitations.`
        });
        notes = llmResponse;
      } catch (error) {
        console.error("Error generating notes:", error);
        notes = "Analysis complete. Please refer to the detailed breakdown above for more information.";
      }
      
      const newResult = await ScanResult.create({
        image_url: file_url,
        result: authenticity,
        confidence_score: confidence,
        details: details,
        notes: notes
      });
      
      if (authenticity === "fake" && userProfiles.length > 0) {
        const profile = userProfiles[0];
        await UserProfile.update(profile.id, {
          successful_detections: (profile.successful_detections || 0) + 1
        });
      }
      
      setScanResult(newResult);
      
    } catch (error) {
      console.error("Error processing image:", error);
    } finally {
      setIsScanning(false);
      checkUserStatus();
    }
  };

  const handleInstallClick = () => {
    if (deferredPrompt) {
      console.log('Triggering install prompt from Scanner page');
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choiceResult) => {
        if (choiceResult.outcome === 'accepted') {
          console.log('User accepted the install prompt');
        } else {
          console.log('User dismissed the install prompt');
        }
        setDeferredPrompt(null);
      });
    } else {
      // If we don't have the deferredPrompt but we're on Android,
      // provide instructions for manual installation
      const isAndroid = /Android/.test(navigator.userAgent);
      if (isAndroid) {
        alert("To install the app, tap the browser menu (⋮) and select 'Add to Home screen' or 'Install app'");
      }
    }
  };

  if (userStatus.isLoading) {
    return (
      <div className="flex items-center justify-center flex-1">
        <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl min-h-screen flex flex-col">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center mb-4">
          <ShieldCheck className="h-10 w-10 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900 mb-3">
          FakeGuard AI Scanner
        </h1>
        <p className="text-gray-600 max-w-xl mx-auto">
          Our AI-powered scanner analyzes product images to detect counterfeit items with high accuracy
        </p>
        {deferredPrompt && (
          <div className="text-center mb-6">
            <Button 
              onClick={handleInstallClick} 
              className="bg-gradient-to-r from-blue-600 to-purple-600"
            >
              <Download className="w-4 h-4 mr-2" />
              Install FakeGuard AI App
            </Button>
          </div>
        )}
      </div>

      <AnimatePresence>
        {!scanResult && (
          <motion.div
            initial={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
          >
            {showCamera ? (
              <CameraCapture 
                onCapture={handleCameraCapture} 
                onClose={() => setShowCamera(false)}
                onError={handleCameraError}
              />
            ) : (
              <Card className="p-8 shadow-lg border-0 bg-white rounded-2xl mb-8">
                <div className="grid md:grid-cols-2 gap-6">
                  <Button
                    onClick={handleCameraClick}
                    className="relative h-[300px] text-lg bg-gradient-to-br from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 text-blue-700 border-2 border-dashed border-blue-200 rounded-xl overflow-hidden group"
                  >
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="flex flex-col items-center">
                        <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                          <Camera className="w-6 h-6 text-blue-600" />
                        </div>
                        <span className="font-medium">Take Photo</span>
                        <span className="text-sm text-blue-600/70 mt-1">
                          {!userStatus.isLoggedIn 
                            ? "Sign in to scan" 
                            : !userStatus.hasAccess 
                              ? "Subscribe to scan" 
                              : scanLimitReached
                                ? "Upgrade to scan"
                                : "Use your camera"}
                        </span>
                      </div>
                    </div>
                  </Button>

                  <div 
                    className="relative h-[300px] rounded-xl overflow-hidden group cursor-pointer"
                    onClick={handleUploadClick}
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-purple-100 hover:from-purple-100 hover:to-purple-200 border-2 border-dashed border-purple-200 rounded-xl flex items-center justify-center">
                      <div className="flex flex-col items-center">
                        <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                          <Upload className="w-6 h-6 text-purple-600" />
                        </div>
                        <span className="font-medium text-purple-700">Upload Image</span>
                        <span className="text-sm text-purple-600/70 mt-1">
                          {!userStatus.isLoggedIn 
                            ? "Sign in to scan" 
                            : !userStatus.hasAccess 
                              ? "Subscribe to scan" 
                              : scanLimitReached
                                ? "Upgrade to scan"
                                : "From your device"}
                        </span>
                      </div>

                      <Input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                      />
                    </div>
                  </div>
                </div>
                
                {!userStatus.isLoggedIn && (
                  <div className="mt-6 bg-blue-50 p-4 rounded-lg text-center">
                    <p className="text-blue-700 mb-2">Sign in to start scanning products</p>
                    <Button 
                      onClick={() => User.login()}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Sign In to Continue
                    </Button>
                  </div>
                )}
                
                {userStatus.isLoggedIn && !userStatus.hasAccess && (
                  <div className="mt-6 bg-amber-50 p-4 rounded-lg text-center">
                    <p className="text-amber-700 mb-2">You need to purchase a plan to scan products</p>
                    <Button 
                      onClick={() => window.location.href = createPageUrl("Pricing")}
                      className="bg-amber-600 hover:bg-amber-700 flex items-center gap-2"
                    >
                      <ShoppingCart className="w-4 h-4" />
                      View Plans
                      <ExternalLink className="w-3 h-3 ml-1" />
                    </Button>
                  </div>
                )}
                
                {scanLimitReached && (
                  <div className="mt-6 bg-red-50 p-6 rounded-lg">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                        <AlertCircle className="w-5 h-5 text-red-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-red-900 mb-1">Scan Limit Reached</h3>
                        <p className="text-red-700 mb-4">
                          You've used all your available scans. Upgrade to continue protecting yourself from counterfeits.
                        </p>
                        <div className="flex flex-wrap gap-3">
                          <Button 
                            onClick={() => window.location.href = createPageUrl("Pricing")}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            <Plus className="w-4 h-4 mr-2" />
                            Buy More Scans
                          </Button>
                          <Button 
                            variant="outline"
                            onClick={() => window.location.href = createPageUrl("Pricing") + "?recommended=subscription"}
                            className="border-red-200 text-red-700 hover:bg-red-50"
                          >
                            <Infinity className="w-4 h-4 mr-2" />
                            Upgrade to Unlimited
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </Card>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {isScanning && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <Card className="p-8 text-center shadow-lg border-0 rounded-2xl mx-4">
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center">
                <Loader2 className="w-8 h-8 text-white animate-spin" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900">
                  AI Analysis in Progress
                </h3>
                <p className="text-gray-500 mt-2">Please wait while our AI verifies the product's authenticity...</p>
              </div>
            </div>
          </Card>
        </div>
      )}

      <AnimatePresence>
        {scanResult && (
          <motion.div
            ref={resultRef}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.3 }}
            className="mb-8"
          >
            <div className="bg-blue-50 p-4 rounded-lg mb-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h3 className="font-medium text-blue-900">Scan Complete</h3>
                <p className="text-blue-700 text-sm">View your analysis results below</p>
              </div>
            </div>
            
            <ScanResultDisplay result={scanResult} onNewScan={() => {
              setScanResult(null);
              setShowCamera(false);
            }} />
          </motion.div>
        )}
      </AnimatePresence>

      <Footer />
    </div>
  );
}
