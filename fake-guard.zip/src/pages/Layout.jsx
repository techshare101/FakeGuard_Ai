

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { UserProfile } from "@/api/entities"; 
import { 
  Camera, 
  LayoutDashboard, 
  UserCircle, 
  LogOut,
  Menu,
  X,
  Shield,
  CreditCard,
  ShoppingCart,
  MessageSquare,
  AlertCircle,
  Plus,
  Infinity
} from "lucide-react";
import { Button } from "@/components/ui/button";
import InstallPrompt from "./components/pwa/InstallPrompt";
import ServiceWorker from './components/pwa/ServiceWorker';

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [installPromptTriggered, setInstallPromptTriggered] = useState(false);

  useEffect(() => {
    loadUser();
    
    // Update meta tags for PWA
    const metaTags = [
      { name: "theme-color", content: "#3b82f6" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-status-bar-style", content: "default" },
      { name: "apple-mobile-web-app-title", content: "FakeGuard AI" },
      { name: "description", content: "FakeGuard AI - Detect counterfeit products with AI-powered scanning technology" },
      { name: "application-name", content: "FakeGuard AI" },
      { name: "mobile-web-app-capable", content: "yes" }
    ];
    
    metaTags.forEach(tag => {
      let element = document.querySelector(`meta[name="${tag.name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('name', tag.name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', tag.content);
    });

    // Add Apple touch icons
    const appleTouchIcons = [
      { size: "152x152", href: "https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon152" },
      { size: "180x180", href: "https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon192" },
      { size: "167x167", href: "https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon152" }
    ];

    appleTouchIcons.forEach(icon => {
      let linkElement = document.querySelector(`link[sizes="${icon.size}"]`);
      if (!linkElement) {
        linkElement = document.createElement('link');
        linkElement.setAttribute('rel', 'apple-touch-icon');
        linkElement.setAttribute('sizes', icon.size);
        document.head.appendChild(linkElement);
      }
      linkElement.setAttribute('href', icon.href);
    });
    
    // Add manifest link
    let manifestLink = document.querySelector('link[rel="manifest"]');
    if (!manifestLink) {
      manifestLink = document.createElement('link');
      manifestLink.setAttribute('rel', 'manifest');
      document.head.appendChild(manifestLink);
    }
    manifestLink.setAttribute('href', createPageUrl("manifest"));
    
    // Add favicon
    let favicon = document.querySelector('link[rel="icon"]');
    if (!favicon) {
      favicon = document.createElement('link');
      favicon.setAttribute('rel', 'icon');
      favicon.setAttribute('type', 'image/png');
      document.head.appendChild(favicon);
    }
    favicon.setAttribute('href', 'https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon192');
    
    // Set title
    document.title = "FakeGuard AI - Product Authentication Scanner";
  }, []);

  // Fix install prompt triggering
  useEffect(() => {
    // Only trigger once per session - avoid infinite loops
    if (!installPromptTriggered && !window.matchMedia('(display-mode: standalone)').matches) {
      // Check if prompt was recently dismissed
      const hasPromptBeenDismissed = localStorage.getItem('installPromptDismissed') === 'true';
      
      if (!hasPromptBeenDismissed) {
        setTimeout(() => {
          try {
            const event = new CustomEvent('showInstallPrompt');
            window.dispatchEvent(event);
            setInstallPromptTriggered(true);
          } catch (error) {
            console.error("Error triggering install prompt:", error);
          }
        }, 3000);
      }
    }
  }, [installPromptTriggered]);

  const loadUser = async () => {
    try {
      setIsLoading(true);
      const userData = await User.me();
      setUser(userData);
      
      const publicPages = ["Scanner", "Pricing", "PaymentSuccess"];
      if (!publicPages.includes(currentPageName)) {
        const userProfiles = await UserProfile.filter({ created_by: userData.email });
        if (userProfiles.length === 0) {
          window.location.href = createPageUrl("Pricing");
          return;
        }
        
        const profile = userProfiles[0];
        const hasAccess = profile.subscription_active || 
                        (profile.available_scans && profile.available_scans > 0) || 
                        profile.payment_status === "paid";
        
        if (!hasAccess) {
          window.location.href = createPageUrl("Pricing");
          return;
        }

        if (profile.available_scans <= 0 && !profile.subscription_active) {
          alert("You've reached your scan limit. Please upgrade your plan or purchase more scans.");
          window.location.href = createPageUrl("Pricing");
          return;
        }
      }
    } catch (error) {
      const publicPages = ["Scanner", "Pricing", "PaymentSuccess"];
      if (!publicPages.includes(currentPageName)) {
        window.location.href = createPageUrl("Scanner");
        return;
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    await User.logout();
    setUser(null);
    window.location.href = createPageUrl("Scanner");
  };

  const handleLogin = async () => {
    try {
      setIsAuthenticating(true);
      await User.login();
      await loadUser();
    } catch (error) {
      console.error("Login failed:", error);
    } finally {
      setIsAuthenticating(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4">
            <div className="w-full h-full rounded-full border-4 border-blue-500 border-t-transparent animate-spin"></div>
          </div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (isAuthenticating) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4">
            <div className="w-full h-full rounded-full border-4 border-blue-500 border-t-transparent animate-spin"></div>
          </div>
          <p className="text-gray-600">Authenticating...</p>
        </div>
      </div>
    );
  }

  const navigationItems = [
    { name: "Scanner", icon: Camera, path: createPageUrl("Scanner") },
    { name: "Dashboard", icon: LayoutDashboard, path: createPageUrl("Dashboard") },
    { name: "Subscription", icon: CreditCard, path: createPageUrl("Subscription") },
    { name: "Pricing", icon: ShoppingCart, path: createPageUrl("Pricing") },
    { name: "Contact", icon: MessageSquare, path: createPageUrl("Contact") },
    { name: "Profile", icon: UserCircle, path: createPageUrl("Profile") }
  ];

  return (
    <div className="flex h-screen bg-[#f8fafc]">
      <ServiceWorker />
      
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside className={`fixed top-0 left-0 z-50 h-full w-72 bg-white shadow-lg transform transition-transform duration-200 ease-in-out lg:relative lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex flex-col h-full">
          <Link 
            to={createPageUrl("Scanner")} 
            className="flex items-center gap-3 p-6 border-b hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600">
              <Shield className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-800">
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">FakeGuard</span> AI
            </h1>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden ml-auto"
              onClick={(e) => {
                e.preventDefault();
                setSidebarOpen(false);
              }}
            >
              <X className="h-5 w-5" />
            </Button>
          </Link>

          <nav className="flex-1 p-4 space-y-1.5">
            {navigationItems.map(item => (
              <Link
                key={item.name}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  currentPageName === item.name
                    ? "bg-gradient-to-r from-blue-500/10 to-purple-500/10 text-blue-700 font-medium shadow-sm"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.name}</span>
              </Link>
            ))}
          </nav>

          <div className="p-4 mx-4 mb-4 rounded-xl bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-100">
            {user && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                    <span className="text-white font-medium">
                      {user.full_name?.[0] || user.email[0].toUpperCase()}
                    </span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-gray-800">
                      {user.full_name || user.email}
                    </span>
                    <span className="text-xs text-gray-500">{user.email}</span>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleLogout}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <LogOut className="h-5 w-5" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        <header className="lg:hidden bg-white border-b px-6 py-4 shadow-sm">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-6 w-6" />
            </Button>
            <Link 
              to={createPageUrl("Scanner")}
              className="flex items-center gap-2"
            >
              <Shield className="h-5 w-5 text-blue-600" />
              <h1 className="text-lg font-semibold text-gray-800">
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">FakeGuard</span> AI
              </h1>
            </Link>
            <div className="w-6" />
          </div>
        </header>

        <main className="flex-1 overflow-auto bg-[#f8fafc]">
          {children}
        </main>
      </div>

      <InstallPrompt />
      
      {!user && (
        <Button
          onClick={handleLogin}
          className="fixed bottom-4 right-4 bg-blue-600 hover:bg-blue-700 text-white z-40"
        >
          Sign In
        </Button>
      )}
    </div>
  );
}

