
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { UserProfile } from "@/api/entities";
import { ScanResult } from "@/api/entities";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { createPageUrl } from "@/utils";
import { 
  CreditCard, 
  Calendar, 
  CheckCircle, 
  ShoppingCart, 
  Infinity, 
  Zap, 
  Clock, 
  Scan,
  ArrowRight,
  AlertTriangle,
  LucideBarChart,
  Hourglass,
  Loader2
} from "lucide-react";
import Footer from "../components/legal/Footer";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";

export default function Subscription() {
  const [userProfile, setUserProfile] = useState(null);
  const [scanResults, setScanResults] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [recentScans, setRecentScans] = useState([]);
  const [showManageDialog, setShowManageDialog] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);

  useEffect(() => {
    loadSubscriptionData();
  }, []);

  const loadSubscriptionData = async () => {
    try {
      const user = await User.me();
      
      const profiles = await UserProfile.filter({ created_by: user.email });
      if (profiles.length > 0) {
        setUserProfile(profiles[0]);
      }
      
      const results = await ScanResult.filter({ created_by: user.email }, "-created_date", 10);
      setScanResults(results);
      
      setRecentScans(results.slice(0, 5));
    } catch (error) {
      console.error("Error loading subscription data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleCancelSubscription = async () => {
    try {
      setIsCancelling(true);
      await UserProfile.update(userProfile.id, {
        subscription_active: false,
        subscription_end_date: new Date().toISOString()
      });
      
      await loadSubscriptionData();
      setShowManageDialog(false);
      
      alert("Your subscription has been cancelled successfully.");
    } catch (error) {
      console.error("Error cancelling subscription:", error);
      alert("Failed to cancel subscription. Please try again or contact support.");
    } finally {
      setIsCancelling(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }
  
  if (!userProfile) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <Card className="border-0 shadow-lg rounded-2xl overflow-hidden">
          <div className="p-8 text-center">
            <AlertTriangle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-4">No Subscription Found</h2>
            <p className="text-gray-600 mb-6">
              You don't have an active subscription or scan package yet.
            </p>
            <Button 
              className="bg-gradient-to-r from-blue-600 to-purple-600"
              onClick={() => window.location.href = createPageUrl("Pricing")}
            >
              <ShoppingCart className="mr-2 h-5 w-5" />
              View Plans
            </Button>
          </div>
        </Card>
      </div>
    );
  }
  
  const hasSubscription = userProfile.subscription_active;
  const hasPrepaidScans = userProfile.available_scans > 0;
  
  const thisMonth = new Date().getMonth();
  const thisYear = new Date().getFullYear();
  const scansThisMonth = scanResults.filter(scan => {
    const scanDate = new Date(scan.created_date);
    return scanDate.getMonth() === thisMonth && scanDate.getFullYear() === thisYear;
  }).length;

  const daysLeft = userProfile.subscription_end_date ? 
    Math.max(0, Math.floor((new Date(userProfile.subscription_end_date) - new Date()) / (1000 * 60 * 60 * 24))) : 0;

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl min-h-screen flex flex-col">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">My Subscription</h1>
        <p className="text-gray-600">Manage your subscription and usage details</p>
      </div>
      
      <div className="space-y-8 flex-1">
        <Card className="border-0 shadow-lg rounded-2xl overflow-hidden">
          <div className="h-24 bg-gradient-to-r from-blue-500 to-purple-600"></div>
          <CardContent className="relative px-6 sm:px-8">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6 -mt-12">
              <div className="w-24 h-24 rounded-xl bg-white p-1 shadow-lg">
                <div className="w-full h-full rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                  {hasSubscription ? (
                    <Infinity className="h-10 w-10 text-white" />
                  ) : (
                    <Scan className="h-10 w-10 text-white" />
                  )}
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  {hasSubscription ? "Unlimited Subscription" : "Pay-Per-Scan Package"}
                </h2>
                <div className="mt-2 flex flex-wrap items-center gap-3">
                  <Badge className="bg-green-100 text-green-800 px-3 py-1 flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" />
                    {hasSubscription ? "Active" : hasPrepaidScans ? "Scans Available" : "Inactive"}
                  </Badge>
                  
                  {hasSubscription && userProfile.subscription_end_date && (
                    <div className="text-sm text-gray-600 flex items-center gap-1">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      Renews: {new Date(userProfile.subscription_end_date).toLocaleDateString()}
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6 mt-8">
              <div className="space-y-6">
                {hasSubscription ? (
                  <>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium text-gray-600">Subscription Period</span>
                        <span className="text-sm font-medium text-gray-900">{daysLeft} days left</span>
                      </div>
                      <Progress value={(30 - daysLeft) / 30 * 100} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium text-gray-600">Monthly Usage</span>
                        <span className="text-sm font-medium text-gray-900">{scansThisMonth} scans this month</span>
                      </div>
                      <div className="bg-blue-100 text-blue-800 text-sm px-3 py-2 rounded-lg flex items-center">
                        <Infinity className="w-4 h-4 mr-2" />
                        Unlimited scans available
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium text-gray-600">Scans Available</span>
                        <span className="text-sm font-medium text-gray-900">
                          {userProfile.available_scans} remaining
                        </span>
                      </div>
                      <Progress 
                        value={userProfile.available_scans / (userProfile.available_scans + (userProfile.total_scans || 0)) * 100} 
                        className="h-2" 
                      />
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium text-gray-600">Total Usage</span>
                        <span className="text-sm font-medium text-gray-900">
                          {userProfile.total_scans || 0} scans used
                        </span>
                      </div>
                      <div className="bg-purple-100 text-purple-800 text-sm px-3 py-2 rounded-lg flex items-center">
                        <Hourglass className="w-4 h-4 mr-2" />
                        {userProfile.available_scans} scans remaining
                      </div>
                    </div>
                  </>
                )}
                
                <div className="p-4 border border-gray-200 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Subscription Details</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Plan Type:</span>
                      <span className="font-medium text-gray-900">
                        {hasSubscription ? "Monthly Unlimited" : "Pay-Per-Scan"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Price:</span>
                      <span className="font-medium text-gray-900">
                        {hasSubscription ? "$9.99/month" : "Varies per package"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Status:</span>
                      <span className="font-medium text-gray-900">
                        {userProfile.payment_status === "paid" ? "Paid" : "Pending"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Recent Activity</h3>
                  {recentScans.length > 0 ? (
                    <div className="space-y-2">
                      {recentScans.map(scan => (
                        <div key={scan.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                          <div className="w-10 h-10 rounded-lg overflow-hidden bg-gray-200 flex-shrink-0">
                            <img 
                              src={scan.image_url} 
                              alt="Scan" 
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <div>
                                <Badge className={`
                                  ${scan.result === 'authentic' ? 'bg-green-100 text-green-800' : 
                                    scan.result === 'suspicious' ? 'bg-yellow-100 text-yellow-800' : 
                                    'bg-red-100 text-red-800'}
                                `}>
                                  {scan.result}
                                </Badge>
                              </div>
                              <span className="text-xs text-gray-500">
                                {new Date(scan.created_date).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-gray-500 bg-gray-50 rounded-lg">
                      <Scan className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                      <p>No recent scans</p>
                    </div>
                  )}
                </div>
                
                <div className="p-5 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100">
                  <h3 className="font-medium text-gray-900 mb-2">
                    {hasSubscription ? "Manage Your Subscription" : "Upgrade Your Plan"}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4">
                    {hasSubscription 
                      ? "Your unlimited subscription gives you access to all features."
                      : "Get unlimited scans with our monthly subscription."}
                  </p>
                  <Button
                    className={hasSubscription 
                      ? "w-full bg-gray-800 hover:bg-gray-700" 
                      : "w-full bg-gradient-to-r from-blue-600 to-purple-600"}
                    onClick={() => hasSubscription ? setShowManageDialog(true) : window.location.href = createPageUrl("Pricing")}
                  >
                    {hasSubscription ? (
                      <>
                        <CreditCard className="mr-2 h-4 w-4" />
                        Manage Subscription
                      </>
                    ) : (
                      <>
                        <Zap className="mr-2 h-4 w-4" />
                        Upgrade to Unlimited
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-0 shadow-md rounded-xl overflow-hidden">
          <CardHeader className="border-b bg-gradient-to-r from-gray-50 to-gray-100">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Usage Statistics</h2>
              <LucideBarChart className="h-5 w-5 text-gray-400" />
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-gray-50 rounded-xl">
                <div className="text-sm text-gray-500 mb-1">Total Scans</div>
                <div className="text-xl font-bold">{userProfile.total_scans || 0}</div>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-xl">
                <div className="text-sm text-gray-500 mb-1">This Month</div>
                <div className="text-xl font-bold">{scansThisMonth}</div>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-xl">
                <div className="text-sm text-gray-500 mb-1">Counterfeits Detected</div>
                <div className="text-xl font-bold">{userProfile.successful_detections || 0}</div>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-xl">
                <div className="text-sm text-gray-500 mb-1">
                  {hasSubscription ? "Days Remaining" : "Scans Left"}
                </div>
                <div className="text-xl font-bold">
                  {hasSubscription ? daysLeft : userProfile.available_scans}
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => window.location.href = createPageUrl("Dashboard")}
              >
                View Full Dashboard
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Dialog open={showManageDialog} onOpenChange={setShowManageDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Manage Your Subscription</DialogTitle>
            <DialogDescription>
              Your unlimited subscription is active until {new Date(userProfile?.subscription_end_date).toLocaleDateString()}.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="bg-amber-50 p-4 rounded-lg">
              <h4 className="font-medium text-amber-800 mb-2 flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                Cancel Subscription
              </h4>
              <p className="text-amber-700 text-sm mb-3">
                If you cancel your subscription, you'll still have access until the end of your current billing period. After that, you'll need to purchase scans individually.
              </p>
              <Button 
                variant="outline" 
                className="border-amber-300 text-amber-800 hover:bg-amber-100 hover:text-amber-900"
                onClick={handleCancelSubscription}
                disabled={isCancelling}
              >
                {isCancelling ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : "Cancel Subscription"}
              </Button>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-800 mb-2 flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Payment Method
              </h4>
              <p className="text-blue-700 text-sm mb-3">
                Update your payment method to ensure uninterrupted service.
              </p>
              <Button
                variant="outline"
                className="border-blue-300 text-blue-800 hover:bg-blue-100 hover:text-blue-900"
                onClick={() => window.location.href = createPageUrl("Pricing")}
              >
                Update Payment Method
              </Button>
            </div>
          </div>
          
          <DialogFooter className="sm:justify-start">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setShowManageDialog(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
}
