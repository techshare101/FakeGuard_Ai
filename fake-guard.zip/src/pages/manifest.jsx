export default function Manifest() {
  const manifestContent = {
    "name": "FakeGuard AI",
    "short_name": "FakeGuard AI",
    "theme_color": "#3b82f6",
    "background_color": "#ffffff",
    "display": "standalone",
    "scope": "/",
    "start_url": "/",
    "description": "Detect counterfeit products with AI-powered scanning technology",
    "orientation": "portrait",
    "icons": [
      {
        "src": "https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon72",
        "sizes": "72x72",
        "type": "image/png",
        "purpose": "any maskable"
      },
      {
        "src": "https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon96",
        "sizes": "96x96",
        "type": "image/png",
        "purpose": "any maskable"
      },
      {
        "src": "https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon128",
        "sizes": "128x128",
        "type": "image/png",
        "purpose": "any maskable"
      },
      {
        "src": "https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon144",
        "sizes": "144x144",
        "type": "image/png",
        "purpose": "any maskable"
      },
      {
        "src": "https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon152",
        "sizes": "152x152",
        "type": "image/png",
        "purpose": "any maskable"
      },
      {
        "src": "https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon192",
        "sizes": "192x192",
        "type": "image/png",
        "purpose": "any maskable"
      },
      {
        "src": "https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon384",
        "sizes": "384x384",
        "type": "image/png",
        "purpose": "any maskable"
      },
      {
        "src": "https://imagedelivery.net/pclTepaOhPXauWzojt_TrQ/ea3baee5-9094-4bb2-5f28-0a9989093d00/icon512",
        "sizes": "512x512",
        "type": "image/png",
        "purpose": "any maskable"
      }
    ]
  };

  return (
    <pre id="manifestContent" style={{ display: 'none' }}>
      {JSON.stringify(manifestContent, null, 2)}
    </pre>
  );
}