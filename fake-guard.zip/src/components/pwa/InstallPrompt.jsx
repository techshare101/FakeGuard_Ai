import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Download, X, Shield } from "lucide-react";

export default function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const promptShownRef = useRef(false);

  useEffect(() => {
    // Check if app is already installed
    const checkIfInstalled = () => {
      const isInstalledCheck = window.matchMedia('(display-mode: standalone)').matches || 
                              window.navigator.standalone || 
                              document.referrer.includes('android-app://');
      setIsInstalled(isInstalledCheck);
      return isInstalledCheck;
    };

    // If already installed, hide the prompt
    if (checkIfInstalled()) {
      setShowPrompt(false);
      return;
    }

    // Detect platform
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    const isAndroidDevice = /Android/.test(navigator.userAgent);
    setIsIOS(isIOSDevice);
    setIsAndroid(isAndroidDevice);
    
    // Check for dismissed status in localStorage
    const hasPromptBeenDismissed = localStorage.getItem('installPromptDismissed') === 'true';
    if (hasPromptBeenDismissed) {
      return;
    }

    // Store the beforeinstallprompt event
    const handleBeforeInstallPrompt = (e) => {
      // Prevent Chrome from automatically showing the prompt
      e.preventDefault();
      console.log('Install prompt captured and saved for later use');
      // Save the event for later use
      setDeferredPrompt(e);
      
      // Show prompt if not already shown
      if (!promptShownRef.current && !checkIfInstalled() && !hasPromptBeenDismissed) {
        setShowPrompt(true);
        promptShownRef.current = true;
      }
    };

    // Listen for the beforeinstallprompt event
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Listen for custom event to show the prompt
    const handleCustomPrompt = () => {
      if (!promptShownRef.current && !checkIfInstalled() && !hasPromptBeenDismissed) {
        console.log("Custom event triggered, showing install prompt");
        setShowPrompt(true);
        promptShownRef.current = true;
      }
    };
    
    window.addEventListener('showInstallPrompt', handleCustomPrompt);

    // Show prompt immediately on iOS (can't use beforeinstallprompt)
    if (isIOSDevice && !checkIfInstalled() && !promptShownRef.current && !hasPromptBeenDismissed) {
      console.log("iOS device detected, showing install instructions");
      setTimeout(() => {
        setShowPrompt(true);
        promptShownRef.current = true;
      }, 1000);
    }

    // Cleanup
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('showInstallPrompt', handleCustomPrompt);
    };
  }, []);

  // Check for installation status changes
  useEffect(() => {
    const handleDisplayModeChange = (e) => {
      if (e.matches) {
        // App is now running in standalone mode
        setShowPrompt(false);
        setIsInstalled(true);
      }
    };

    const mediaQuery = window.matchMedia('(display-mode: standalone)');
    mediaQuery.addEventListener('change', handleDisplayModeChange);

    return () => {
      mediaQuery.removeEventListener('change', handleDisplayModeChange);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      try {
        console.log("Install button clicked, triggering native prompt");
        // Show native prompt
        await deferredPrompt.prompt();
        
        // Wait for user choice
        const { outcome } = await deferredPrompt.userChoice;
        console.log(`User response: ${outcome}`);
        
        // We've used the prompt, discard it
        setDeferredPrompt(null);
        
        if (outcome === 'accepted') {
          setShowPrompt(false);
        }
      } catch (error) {
        console.error('Error during installation:', error);
      }
    } else if (isAndroid) {
      // Manual instructions for Android
      alert("To install FakeGuard AI, tap the menu button (⋮) and select 'Install app' or 'Add to Home Screen'");
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    // Remember this dismissal in localStorage so it won't show again in this session
    localStorage.setItem('installPromptDismissed', 'true');
    
    // Set a timeout to reset this after 24 hours
    setTimeout(() => {
      localStorage.removeItem('installPromptDismissed');
    }, 24 * 60 * 60 * 1000); // 24 hours
  };

  // Don't show if already installed or dismissed
  if (isInstalled || !showPrompt) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 max-w-xl mx-auto">
      <Card className="p-4 shadow-xl border-0 rounded-xl bg-white">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
            <Shield className="h-5 w-5 text-white" />
          </div>
          
          <div className="flex-1">
            <div className="font-medium">Install FakeGuard AI</div>
            <p className="text-sm text-gray-600 mt-1">
              {isIOS 
                ? "Add to Home Screen for the best experience: tap Share then 'Add to Home Screen'"
                : "Install our app for faster scanning and offline access"}
            </p>
            
            {!isIOS && deferredPrompt && (
              <Button
                onClick={handleInstallClick}
                className="mt-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                size="sm"
              >
                <Download className="w-4 h-4 mr-2" />
                Install FakeGuard AI
              </Button>
            )}
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            className="flex-shrink-0 h-8 w-8 p-0"
            onClick={handleDismiss}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </Card>
    </div>
  );
}