
import React, { useRef, useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera, X, SwitchCamera, ImageIcon, AlertCircle } from "lucide-react";

export default function CameraCapture({ onCapture, onClose, onError }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [facingMode, setFacingMode] = useState("environment"); // Default to rear camera
  const [cameraError, setCameraError] = useState(null);
  const [availableCameras, setAvailableCameras] = useState([]);
  const [attemptCount, setAttemptCount] = useState(0);
  const [promptTriggered, setPromptTriggered] = useState(false);

  useEffect(() => {
    const startCamera = async () => {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error("Your browser doesn't support camera access");
        }

        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: facingMode // Use environment (rear) camera by default
          },
          audio: false
        });
        
        streamRef.current = stream;
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
            videoRef.current.play()
              .then(() => {
                setIsCameraReady(true);
                setCameraError(null);
                checkForAvailableCameras();
              })
              .catch(error => {
                console.error("Could not play video:", error);
                handleCameraError(error);
              });
          };
        }
      } catch (error) {
        console.error("Camera start failed with facing mode " + facingMode + ":", error);
        
        if (facingMode === "environment") {
          console.log("Trying fallback to front camera...");
          setFacingMode("user");
          setAttemptCount(count => count + 1);
          return;
        }
        
        handleCameraError(error);
        
        if (onError) {
          onError(error.message || "Could not access camera");
        }
      }
    };
    
    startCamera();
    
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
      }
    };
  }, [attemptCount, facingMode]);

  const checkForAvailableCameras = async () => {
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const cameras = devices.filter(device => device.kind === 'videoinput');
      console.log('Available cameras:', cameras);
      setAvailableCameras(cameras);
    } catch (error) {
      console.error("Failed to enumerate devices:", error);
    }
  };

  const handleCameraError = (error) => {
    console.error("Camera error:", error);
    let errorMessage = "Could not access camera. ";

    if (error.name === 'NotAllowedError') {
      errorMessage += "Camera permission denied. Please check your browser settings.";
    } else if (error.name === 'NotFoundError') {
      errorMessage += "No camera found on your device.";
    } else if (error.name === 'NotReadableError') {
      errorMessage += "Camera is in use by another application.";
    } else if (error.message) {
      errorMessage += error.message;
    }

    setCameraError(errorMessage);
    setIsCameraReady(false);
  };

  const switchCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;

      setFacingMode(current => current === "user" ? "environment" : "user");
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !isCameraReady) return;

    try {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        throw new Error("Could not create canvas context");
      }

      ctx.drawImage(videoRef.current, 0, 0);

      canvas.toBlob(blob => {
        if (!blob) {
          throw new Error('Failed to capture image');
        }

        const file = new File([blob], `scan-${Date.now()}.jpg`, { type: 'image/jpeg' });
        onCapture(file);
      }, 'image/jpeg', 0.8);
    } catch (error) {
      console.error('Failed to capture photo:', error);
      alert("Failed to capture photo. Please try again or upload an image instead.");
    }
  };

  const retryCamera = () => {
    setAttemptCount(count => count + 1);
  };

  useEffect(() => {
    if (isCameraReady && !promptTriggered) {
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches || 
                          window.navigator.standalone || 
                          document.referrer.includes('android-app://');
                          
      if (!isStandalone) {
        console.log('Camera ready - triggering install prompt');
        // Dispatch event with high priority, but only once
        setTimeout(() => {
          try {
            const event = new CustomEvent('showInstallPrompt');
            window.dispatchEvent(event);
            setPromptTriggered(true);
          } catch (error) {
            console.error("Error triggering install prompt:", error);
          }
        }, 1000);
      }
    }
  }, [isCameraReady, promptTriggered]);

  return (
    <Card className="relative overflow-hidden rounded-2xl shadow-2xl border-0 mb-8">
      <div className="aspect-[4/3] bg-black relative">
        {cameraError ? (
          <div className="absolute inset-0 flex items-center justify-center text-center p-6 bg-gray-900">
            <div className="max-w-md">
              <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-white mb-2">Camera Error</h3>
              <p className="text-gray-300 mb-4">{cameraError}</p>
              <div className="flex flex-col gap-3">
                <Button 
                  onClick={retryCamera}
                  variant="outline"
                  className="bg-blue-600 text-white hover:bg-blue-700 border-0"
                >
                  Try Again
                </Button>
                <Button
                  onClick={onClose}
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/10"
                >
                  Upload Image Instead
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="absolute inset-0 w-full h-full object-cover"
            />
            {!isCameraReady && (
              <div className="absolute inset-0 flex items-center justify-center text-white">
                <div className="animate-spin rounded-full h-10 w-10 border-2 border-white border-opacity-30 border-t-white" />
              </div>
            )}
          </>
        )}
      </div>

      <div className="absolute top-4 right-4 flex gap-2">
        {availableCameras.length > 1 && isCameraReady && (
          <Button
            variant="outline"
            size="icon"
            className="bg-white/90 backdrop-blur-sm hover:bg-white rounded-full shadow-lg border-0"
            onClick={switchCamera}
          >
            <SwitchCamera className="h-4 w-4" />
          </Button>
        )}
        <Button
          variant="outline"
          size="icon"
          className="bg-white/90 backdrop-blur-sm hover:bg-white rounded-full shadow-lg border-0"
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {isCameraReady && (
        <>
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-4">
            <Button
              size="lg"
              className="rounded-full w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 shadow-lg border-0 hover:shadow-blue-500/25"
              onClick={capturePhoto}
            >
              <Camera className="h-7 w-7 text-white" />
            </Button>
          </div>

          <div className="absolute bottom-6 left-6">
            <div className="px-3 py-1.5 bg-black/60 backdrop-blur-sm text-white rounded-full text-xs flex items-center gap-1.5">
              <ImageIcon className="h-3 w-3" />
              <span>Position product in frame</span>
            </div>
          </div>
        </>
      )}
    </Card>
  );
}
