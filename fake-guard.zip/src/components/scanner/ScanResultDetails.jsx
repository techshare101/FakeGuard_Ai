import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Calendar,
  Maximize2,
  Download,
  Share2
} from "lucide-react";
import { format } from "date-fns";

export default function ScanResultDetails({ result, isOpen, onClose }) {
  if (!result) return null;
  
  const resultConfig = {
    authentic: {
      icon: CheckCircle,
      color: "text-green-600",
      bgColor: "bg-green-50",
      border: "border-green-200",
      badge: "bg-green-100 text-green-800",
      title: "Authentic Product Verified"
    },
    suspicious: {
      icon: AlertTriangle,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
      border: "border-yellow-200",
      badge: "bg-yellow-100 text-yellow-800",
      title: "Suspicious Product Detected"
    },
    fake: {
      icon: XCircle,
      color: "text-red-600",
      bgColor: "bg-red-50",
      border: "border-red-200",
      badge: "bg-red-100 text-red-800",
      title: "Counterfeit Product Detected"
    }
  };
  
  const config = resultConfig[result.result];
  const ResultIcon = config.icon;
  const scanDate = new Date(result.created_date);
  
  const handleDownload = () => {
    // Create a temporary link to download the image
    const link = document.createElement('a');
    link.href = result.image_url;
    link.download = `scan-${format(scanDate, 'yyyy-MM-dd')}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Product Scan Result: ${result.result}`,
          text: `FakeGuard AI scan result: ${result.result} (${result.confidence_score}% confidence)`,
          url: window.location.href
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      alert('Web Share API not supported on this browser');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Scan Details</DialogTitle>
        </DialogHeader>
        
        <div className={`rounded-lg p-4 ${config.bgColor} ${config.border} border mb-4`}>
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${config.bgColor}`}>
              <ResultIcon className={`w-6 h-6 ${config.color}`} />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">{config.title}</h3>
              <div className="flex items-center gap-2">
                <Badge className={config.badge}>
                  {result.result.charAt(0).toUpperCase() + result.result.slice(1)}
                </Badge>
                <span className="text-sm text-gray-600">
                  {result.confidence_score}% confidence
                </span>
              </div>
            </div>
          </div>
          
          <div className="text-sm text-gray-600 flex items-center gap-2 mb-3">
            <Calendar className="w-4 h-4 text-gray-400" />
            <span>Scanned on {format(scanDate, "MMMM d, yyyy 'at' h:mm a")}</span>
          </div>
          
          {result.notes && (
            <div className="text-sm text-gray-700 mt-2 p-3 bg-white/50 rounded-md">
              {result.notes}
            </div>
          )}
        </div>
        
        <div className="relative rounded-lg overflow-hidden mb-4 group">
          <img 
            src={result.image_url} 
            alt="Scanned product"
            className="w-full object-contain max-h-[300px]"
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
            <Button 
              variant="outline" 
              size="icon"
              className="bg-white/80 hover:bg-white" 
              onClick={() => window.open(result.image_url, '_blank')}
            >
              <Maximize2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="flex flex-col p-3 rounded-lg border">
            <span className="text-xs text-gray-500 mb-1">Brand Match</span>
            <div className="flex items-center">
              {result.details?.brand_match ? (
                <CheckCircle className="w-4 h-4 text-green-500 mr-1.5" />
              ) : (
                <XCircle className="w-4 h-4 text-red-500 mr-1.5" />
              )}
              <span className="font-medium">
                {result.details?.brand_match ? "Passed" : "Failed"}
              </span>
            </div>
          </div>
          
          <div className="flex flex-col p-3 rounded-lg border">
            <span className="text-xs text-gray-500 mb-1">Texture Analysis</span>
            <div className="flex items-center">
              {result.details?.texture_analysis ? (
                <CheckCircle className="w-4 h-4 text-green-500 mr-1.5" />
              ) : (
                <XCircle className="w-4 h-4 text-red-500 mr-1.5" />
              )}
              <span className="font-medium">
                {result.details?.texture_analysis ? "Passed" : "Failed"}
              </span>
            </div>
          </div>
          
          <div className="flex flex-col p-3 rounded-lg border">
            <span className="text-xs text-gray-500 mb-1">Pattern Check</span>
            <div className="flex items-center">
              {result.details?.pattern_check ? (
                <CheckCircle className="w-4 h-4 text-green-500 mr-1.5" />
              ) : (
                <XCircle className="w-4 h-4 text-red-500 mr-1.5" />
              )}
              <span className="font-medium">
                {result.details?.pattern_check ? "Passed" : "Failed"}
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between">
          <Button variant="outline" onClick={handleDownload} className="flex items-center gap-2">
            <Download className="w-4 h-4" />
            Download
          </Button>
          
          <Button variant="outline" onClick={handleShare} className="flex items-center gap-2">
            <Share2 className="w-4 h-4" />
            Share
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}