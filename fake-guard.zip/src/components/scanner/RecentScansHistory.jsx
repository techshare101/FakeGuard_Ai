
import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { User } from "@/api/entities";
import { ScanResult } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Calendar, 
  Clock, 
  Image as ImageIcon,
  ExternalLink
} from "lucide-react";
import { format } from "date-fns";
import ScanResultDetails from "./ScanResultDetails";

export default function RecentScansHistory({ isOpen, onClose }) {
  const [scanResults, setScanResults] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedScan, setSelectedScan] = useState(null);
  
  useEffect(() => {
    if (isOpen) {
      loadScanResults();
    }
  }, [isOpen]);
  
  const loadScanResults = async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      const results = await ScanResult.filter(
        { created_by: user.email },
        "-created_date",
        10 // Reduced from 20 to 10 for faster loading
      );
      setScanResults(results);
    } catch (error) {
      console.error("Error loading scan history:", error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const resultConfig = {
    authentic: {
      icon: CheckCircle,
      color: "text-green-600",
      badge: "bg-green-100 text-green-800"
    },
    suspicious: {
      icon: AlertTriangle,
      color: "text-yellow-600",
      badge: "bg-yellow-100 text-yellow-800"
    },
    fake: {
      icon: XCircle,
      color: "text-red-600",
      badge: "bg-red-100 text-red-800"
    }
  };
  
  const handleScanSelect = (scan) => {
    setSelectedScan(scan);
  };
  
  const handleCloseScanDetails = () => {
    setSelectedScan(null);
  };
  
  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Recent Scan History
            </DialogTitle>
          </DialogHeader>
          
          <div className="overflow-y-auto max-h-[calc(80vh-120px)] pr-1">
            {isLoading ? (
              <div className="py-12 flex justify-center">
                <div className="animate-spin rounded-full h-10 w-10 border-4 border-blue-500 border-t-transparent"></div>
              </div>
            ) : scanResults.length === 0 ? (
              <div className="py-8 text-center">
                <ImageIcon className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No scan history available</p>
                <p className="text-sm text-gray-400">Try scanning a product first</p>
              </div>
            ) : (
              <div className="space-y-3 pt-2">
                {scanResults.map((scan) => {
                  const config = resultConfig[scan.result];
                  const ResultIcon = config.icon;
                  const scanTime = new Date(scan.created_date);
                  
                  return (
                    <div
                      key={scan.id}
                      className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() => handleScanSelect(scan)}
                    >
                      <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                        <img
                          src={scan.image_url}
                          alt="Scanned product"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <ResultIcon className={`w-4 h-4 ${config.color}`} />
                          <Badge className={config.badge}>
                            {scan.result.charAt(0).toUpperCase() + scan.result.slice(1)}
                          </Badge>
                          <span className="text-sm text-gray-500">
                            {scan.confidence_score}% confidence
                          </span>
                        </div>
                        
                        <div className="text-xs text-gray-600 flex items-center gap-3">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-gray-400" />
                            {format(scanTime, "MMM d, yyyy")}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3 text-gray-400" />
                            {format(scanTime, "h:mm a")}
                          </div>
                        </div>
                      </div>
                      
                      <ExternalLink className="w-4 h-4 text-gray-400" />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Scan details dialog */}
      {selectedScan && (
        <ScanResultDetails
          result={selectedScan}
          isOpen={!!selectedScan}
          onClose={handleCloseScanDetails}
        />
      )}
    </>
  );
}
