
import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { createPageUrl } from "@/utils";
import { 
  CheckCircle, 
  AlertTriangle, 
  XCircle,
  Camera,
  BarChart,
  AlertCircle,
  ArrowUpRight 
} from "lucide-react";

const resultConfig = {
  authentic: {
    icon: CheckCircle,
    color: "text-green-600",
    bgColor: "bg-green-50",
    gradient: "from-green-500 to-emerald-500",
    badge: "bg-green-100 text-green-800",
    title: "Product Appears Authentic",
    description: "Our AI analysis indicates this product shows strong signs of authenticity."
  },
  suspicious: {
    icon: AlertTriangle,
    color: "text-yellow-600",
    bgColor: "bg-yellow-50",
    gradient: "from-yellow-500 to-amber-500",
    badge: "bg-yellow-100 text-yellow-800",
    title: "Suspicious Product",
    description: "Some aspects of this product require closer inspection."
  },
  fake: {
    icon: XCircle,
    color: "text-red-600",
    bgColor: "bg-red-50",
    gradient: "from-red-500 to-pink-500",
    badge: "bg-red-100 text-red-800",
    title: "Likely Counterfeit",
    description: "This product shows strong indicators of being counterfeit."
  }
};

export default function ScanResult({ result, onNewScan }) {
  const config = resultConfig[result.result];
  const ResultIcon = config.icon;

  return (
    <Card className={`p-6 md:p-8 border-0 rounded-2xl shadow-xl`}>
      <div className="absolute top-0 left-0 w-full h-40 bg-gradient-to-r ${config.gradient} rounded-t-2xl"></div>
      
      <div className="relative text-center mb-8 pt-6">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-white mb-6 shadow-lg">
          <ResultIcon className={`w-10 h-10 ${config.color}`} />
        </div>
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-3">
          {config.title}
        </h2>
        <p className="text-gray-600 max-w-lg mx-auto">{config.description}</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-8">
        <div className="space-y-6">
          <div className="bg-white rounded-xl p-6 shadow-md">
            <div className="text-sm font-medium text-gray-500 mb-3">
              Confidence Score
            </div>
            <div className="flex items-center gap-3 mb-3">
              <div className="flex-1 h-6 bg-gray-100 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full bg-gradient-to-r ${
                    result.confidence_score > 80 ? "from-green-500 to-emerald-600" :
                    result.confidence_score > 50 ? "from-yellow-500 to-amber-600" :
                    "from-red-500 to-pink-600"
                  }`}
                  style={{ width: `${result.confidence_score}%` }}
                />
              </div>
              <span className="font-bold text-xl bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
                {result.confidence_score}%
              </span>
            </div>
            <p className="text-sm text-gray-500">
              {result.confidence_score > 80 ? "High confidence in analysis" :
               result.confidence_score > 50 ? "Moderate confidence in analysis" :
               "Low confidence in analysis"}
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-md">
            <div className="text-sm font-medium text-gray-500 mb-3">
              Analysis Details
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="font-medium">Brand Match</span>
                {result.details.brand_match ? (
                  <Badge className="bg-green-100 text-green-800 px-3 py-1">
                    <CheckCircle className="w-3 h-3 mr-1" /> Pass
                  </Badge>
                ) : (
                  <Badge className="bg-red-100 text-red-800 px-3 py-1">
                    <XCircle className="w-3 h-3 mr-1" /> Fail
                  </Badge>
                )}
              </div>
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="font-medium">Texture Analysis</span>
                {result.details.texture_analysis ? (
                  <Badge className="bg-green-100 text-green-800 px-3 py-1">
                    <CheckCircle className="w-3 h-3 mr-1" /> Pass
                  </Badge>
                ) : (
                  <Badge className="bg-red-100 text-red-800 px-3 py-1">
                    <XCircle className="w-3 h-3 mr-1" /> Fail
                  </Badge>
                )}
              </div>
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="font-medium">Pattern Check</span>
                {result.details.pattern_check ? (
                  <Badge className="bg-green-100 text-green-800 px-3 py-1">
                    <CheckCircle className="w-3 h-3 mr-1" /> Pass
                  </Badge>
                ) : (
                  <Badge className="bg-red-100 text-red-800 px-3 py-1">
                    <XCircle className="w-3 h-3 mr-1" /> Fail
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>

        <div>
          <div className="bg-white rounded-xl overflow-hidden shadow-md">
            <div className="p-6 border-b border-gray-100">
              <div className="text-sm font-medium text-gray-500 mb-1">
                Scanned Image
              </div>
              <div className="text-xs text-gray-400">Original product photo</div>
            </div>
            <div className="aspect-square bg-gray-50 relative overflow-hidden">
              <img 
                src={result.image_url} 
                alt="Scanned product"
                className="w-full h-full object-contain"
              />
              
              {/* Image overlay for AI hotspots */}
              {!result.details.brand_match && (
                <div className="absolute top-5 left-5 w-6 h-6 rounded-full bg-red-500/80 animate-pulse flex items-center justify-center">
                  <AlertCircle className="w-4 h-4 text-white" />
                </div>
              )}
              
              {!result.details.pattern_check && (
                <div className="absolute bottom-10 right-10 w-6 h-6 rounded-full bg-red-500/80 animate-pulse flex items-center justify-center">
                  <AlertCircle className="w-4 h-4 text-white" />
                </div>
              )}
            </div>
          </div>
          
          {result.notes && (
            <div className="mt-6 bg-white rounded-xl p-6 shadow-md">
              <div className="text-sm font-medium text-gray-500 mb-3">
                Additional Notes
              </div>
              <p className="text-gray-600 text-sm">
                {result.notes}
              </p>
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-wrap justify-center gap-4 border-t border-gray-100 pt-6">
        <Button
          variant="outline"
          onClick={onNewScan}
          className="flex items-center gap-2 px-6 py-6 rounded-full border border-gray-200"
        >
          <Camera className="w-5 h-5" />
          <span className="font-medium">Scan Another Product</span>
        </Button>
        <Button
          onClick={() => window.location.href = createPageUrl("Dashboard")}
          className="flex items-center gap-2 px-6 py-6 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 text-white border-0 hover:shadow-lg hover:shadow-blue-500/25 transition-all"
        >
          <BarChart className="w-5 h-5" />
          <span className="font-medium">View Dashboard</span>
          <ArrowUpRight className="w-4 h-4 ml-1" />
        </Button>
      </div>
    </Card>
  );
}
