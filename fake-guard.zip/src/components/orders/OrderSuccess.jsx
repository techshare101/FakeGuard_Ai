import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, ExternalLink, ArrowLeft } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function OrderSuccess({ orderDetails, paymentLink, planDetails }) {
  const handlePayNow = () => {
    window.open(paymentLink, '_blank');
  };

  const getOrderSummary = () => {
    if (planDetails.type === "subscription") {
      return "Unlimited Scan Subscription Plan ($9.99/month)";
    } else {
      const packageInfo = {
        5: { price: 4.95, perScan: 0.99 },
        10: { price: 9.90, perScan: 0.99 },
        20: { price: 17.80, perScan: 0.89 },
        50: { price: 39.50, perScan: 0.79 }
      };
      
      const info = packageInfo[planDetails.scanCount] || packageInfo[5];
      return `Pay-Per-Scan Package (${planDetails.scanCount} scans at $${info.perScan} per scan = $${info.price})`;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <Card className="p-8 border-0 shadow-xl rounded-xl">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Order Received!</h1>
          <p className="text-gray-600">
            We've sent payment instructions to your email. Please check your inbox.
          </p>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg mb-6">
          <h3 className="font-medium mb-2">Order Summary</h3>
          <p>{getOrderSummary()}</p>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg mb-6 border border-blue-100">
          <h3 className="font-medium mb-2 text-blue-800">Payment Instructions</h3>
          <p className="text-blue-700 text-sm mb-2">
            To complete your order, please pay using the secure payment link we've sent to your email ({orderDetails.email}).
          </p>
          <p className="text-blue-700 text-sm">
            You can also pay now by clicking the button below.
          </p>
        </div>

        <div className="space-y-4">
          <Button 
            onClick={handlePayNow}
            className="w-full py-6 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl"
          >
            <ExternalLink className="w-5 h-5 mr-2" />
            Complete Payment Now
          </Button>
          
          <Button
            variant="outline"
            onClick={() => window.location.href = createPageUrl("Scanner")}
            className="w-full py-6 rounded-xl"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Return to Scanner
          </Button>
        </div>

        <div className="mt-6 pt-6 border-t border-gray-100 text-center text-sm text-gray-500">
          <p>If you have any questions about your order, please contact our support team.</p>
        </div>
      </Card>
    </div>
  );
}