
import React from "react";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { CheckCircle, AlertTriangle, XCircle, Calendar, ArrowUpRight, Scan } from "lucide-react";

const resultConfig = {
  authentic: {
    icon: CheckCircle,
    color: "text-green-600",
    badge: "bg-green-100 text-green-800"
  },
  suspicious: {
    icon: AlertTriangle,
    color: "text-yellow-600",
    badge: "bg-yellow-100 text-yellow-800"
  },
  fake: {
    icon: XCircle,
    color: "text-red-600",
    badge: "bg-red-100 text-red-800"
  }
};

export default function Dashboard({ scanResults, isLoading }) {
  if (isLoading) {
    return (
      <Card className="border-0 shadow-md rounded-xl overflow-hidden">
        <CardHeader className="border-b bg-gradient-to-r from-gray-50 to-gray-100">
          <Skeleton className="h-6 w-32" />
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center gap-4 p-4">
                <Skeleton className="h-12 w-12 rounded-lg" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-24 mb-2" />
                  <Skeleton className="h-3 w-32" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-md rounded-xl overflow-hidden">
      <CardHeader className="border-b bg-gradient-to-r from-gray-50 to-gray-100">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Recent Scans</h2>
          <ArrowUpRight className="h-4 w-4 text-gray-400" />
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y">
          {scanResults.slice(0, 5).map((scan) => {
            const config = resultConfig[scan.result];
            const ResultIcon = config.icon;

            return (
              <div
                key={scan.id}
                className="flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100">
                  <img
                    src={scan.image_url}
                    alt="Scanned product"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <ResultIcon className={`w-4 h-4 ${config.color}`} />
                    <Badge className={config.badge}>
                      {scan.result.charAt(0).toUpperCase() + scan.result.slice(1)}
                    </Badge>
                    <span className="text-sm text-gray-500">
                      {scan.confidence_score}% confidence
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-gray-400" />
                    {format(new Date(scan.created_date), "MMM d, yyyy")}
                  </div>
                </div>
              </div>
            );
          })}

          {scanResults.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <div className="w-16 h-16 mx-auto rounded-full bg-gray-100 flex items-center justify-center mb-3">
                <Scan className="w-6 h-6 text-gray-400" />
              </div>
              <p>No scan history available</p>
              <p className="text-sm text-gray-400 mt-1">Scan a product to get started</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
