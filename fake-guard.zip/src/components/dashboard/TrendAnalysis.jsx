import React from "react";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowUpRight } from "lucide-react";
import {
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from "recharts";

export default function TrendAnalysis({ scanResults, isLoading }) {
  if (isLoading) {
    return (
      <Card className="border-0 shadow-md rounded-xl overflow-hidden">
        <CardHeader className="border-b bg-gradient-to-r from-gray-50 to-gray-100">
          <Skeleton className="h-6 w-32" />
        </CardHeader>
        <CardContent className="h-[300px]">
          <Skeleton className="w-full h-full rounded-lg" />
        </CardContent>
      </Card>
    );
  }

  // Process data for chart
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - i);
    return date.toISOString().split('T')[0];
  }).reverse();

  const dailyData = last7Days.map(date => {
    const dayScans = scanResults.filter(scan => 
      scan.created_date.split('T')[0] === date
    );

    return {
      date: new Date(date).toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
      }),
      authentic: dayScans.filter(scan => scan.result === 'authentic').length,
      suspicious: dayScans.filter(scan => scan.result === 'suspicious').length,
      fake: dayScans.filter(scan => scan.result === 'fake').length,
    };
  });

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      const total = payload.reduce((sum, entry) => sum + entry.value, 0);
      
      return (
        <div className="bg-white p-3 border border-gray-100 shadow-md rounded-lg">
          <p className="font-medium">{label}</p>
          <div className="mt-2 space-y-1">
            {payload.map((entry, index) => (
              <div key={index} className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: entry.color }}
                />
                <span className="text-sm text-gray-700">
                  {entry.name}: {entry.value}
                </span>
              </div>
            ))}
            {total > 0 && (
              <div className="pt-1 mt-1 border-t text-sm font-medium">
                Total: {total}
              </div>
            )}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="border-0 shadow-md rounded-xl overflow-hidden">
      <CardHeader className="border-b bg-gradient-to-r from-gray-50 to-gray-100">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Scan Trends</h2>
          <ArrowUpRight className="h-4 w-4 text-gray-400" />
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <RechartsBarChart data={dailyData} barGap={4} barSize={20}>
              <defs>
                <linearGradient id="colorAuthentic" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22c55e" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#22c55e" stopOpacity={0.6}/>
                </linearGradient>
                <linearGradient id="colorSuspicious" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#eab308" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#eab308" stopOpacity={0.6}/>
                </linearGradient>
                <linearGradient id="colorFake" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0.6}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="date" 
                axisLine={false}
                tickLine={false}
                tick={{fontSize: 12}}
              />
              <YAxis 
                allowDecimals={false}
                axisLine={false}
                tickLine={false}
                tick={{fontSize: 12}}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                iconType="circle" 
                wrapperStyle={{fontSize: 12, paddingTop: 20}}
              />
              <Bar 
                dataKey="authentic" 
                name="Authentic" 
                radius={[4, 4, 0, 0]} 
                fill="url(#colorAuthentic)" 
              />
              <Bar 
                dataKey="suspicious" 
                name="Suspicious" 
                radius={[4, 4, 0, 0]} 
                fill="url(#colorSuspicious)" 
              />
              <Bar 
                dataKey="fake" 
                name="Fake" 
                radius={[4, 4, 0, 0]} 
                fill="url(#colorFake)" 
              />
            </RechartsBarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}