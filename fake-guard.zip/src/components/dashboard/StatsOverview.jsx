import React from "react";
import { Card } from "@/components/ui/card";
import { Scan, ShieldCheck, AlertTriangle, ArrowUpRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function StatsOverview({ scanResults, userProfile, isLoading }) {
  if (isLoading) {
    return (
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="p-6 border-0 shadow-md rounded-xl">
            <Skeleton className="h-10 w-10 rounded-lg mb-4" />
            <Skeleton className="h-4 w-24 mb-2" />
            <Skeleton className="h-8 w-16" />
          </Card>
        ))}
      </div>
    );
  }

  const totalScans = userProfile?.total_scans || 0;
  const authenticCount = scanResults.filter(r => r.result === "authentic").length;
  const fakeCount = scanResults.filter(r => r.result === "fake").length;

  const stats = [
    {
      title: "Total Scans",
      value: totalScans,
      icon: Scan,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      gradient: "from-blue-500 to-purple-600"
    },
    {
      title: "Authentic Products",
      value: authenticCount,
      icon: ShieldCheck,
      color: "text-green-600",
      bgColor: "bg-green-50",
      gradient: "from-green-500 to-emerald-600"
    },
    {
      title: "Fakes Detected",
      value: fakeCount,
      icon: AlertTriangle,
      color: "text-red-600",
      bgColor: "bg-red-50",
      gradient: "from-red-500 to-pink-600"
    }
  ];

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      {stats.map((stat, index) => (
        <Card key={index} className="p-6 border-0 overflow-hidden rounded-xl shadow-md relative group hover:shadow-lg transition-all">
          <div className="absolute inset-0 bg-gradient-to-br opacity-5 group-hover:opacity-10 transition-opacity ${stat.gradient}"></div>
          <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center mb-4 shadow-md`}>
            <stat.icon className="w-6 h-6 text-white" />
          </div>
          <div className="text-sm font-medium text-gray-600">{stat.title}</div>
          <div className="text-3xl font-bold mt-1 flex items-center">
            {stat.value}
            <ArrowUpRight className="w-4 h-4 ml-2 text-gray-400" />
          </div>
        </Card>
      ))}
    </div>
  );
}