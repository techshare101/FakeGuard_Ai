import React from "react";
import { Card } from "@/components/ui/card";
import { AlertTriangle, AlertCircle } from "lucide-react";

export default function LegalDisclaimer() {
  return (
    <Card className="p-6 bg-gradient-to-r from-gray-50 to-gray-100 border border-gray-200">
      <div className="flex items-start gap-3">
        <div className="mt-1">
          <AlertTriangle className="w-5 h-5 text-amber-500" />
        </div>
        <div className="space-y-4 text-sm">
          <div>
            <h3 className="font-semibold text-gray-900 mb-1">Accuracy Disclaimer</h3>
            <p className="text-gray-600">
              FakeGuard AI provides product authenticity analysis based on artificial intelligence. While we strive for accuracy, our AI system is not infallible and should be used as a supplementary tool, not as the sole determinant for authenticity.
            </p>
          </div>
          
          <div>
            <h3 className="font-semibold text-gray-900 mb-1">Terms of Use</h3>
            <ul className="text-gray-600 space-y-2">
              <li className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
                <span>Results are provided "as is" without any warranty of accuracy. The AI analysis should be considered as one of many factors in determining authenticity.</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
                <span>For definitive authentication, please consult official brand representatives or authorized authentication services.</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
                <span>We are not liable for any decisions, purchases, or actions taken based on our AI analysis results.</span>
              </li>
            </ul>
          </div>
          
          <p className="text-xs text-gray-500 border-t border-gray-200 pt-4 mt-4">
            By using FakeGuard AI, you acknowledge these limitations and agree to use the service responsibly, understanding that AI analysis is a helpful tool but not a guarantee of product authenticity.
          </p>
        </div>
      </div>
    </Card>
  );
}