import React, { useState } from "react";
import { Shield } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import LegalDisclaimer from "./LegalDisclaimer";

export default function Footer() {
  const [showTerms, setShowTerms] = useState(false);
  const [showDisclaimer, setShowDisclaimer] = useState(false);
  
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="mt-auto py-6 border-t border-gray-200 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-medium">
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">FakeGuard</span> AI
            </span>
          </div>
          
          <div className="text-xs text-gray-500">
            © 2025 FakeGuard AI. All rights reserved. MetalMindTech
          </div>
          
          <div className="flex gap-4 text-sm">
            <button 
              onClick={() => setShowTerms(true)}
              className="text-gray-600 hover:text-blue-600 transition-colors"
            >
              Terms of Use
            </button>
            <button 
              onClick={() => setShowDisclaimer(true)}
              className="text-gray-600 hover:text-blue-600 transition-colors"
            >
              Disclaimer
            </button>
          </div>
        </div>
      </div>
      
      <Dialog open={showTerms} onOpenChange={setShowTerms}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Terms of Use</DialogTitle>
            <DialogDescription>
              Last updated: January 1, 2025
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 text-sm">
            <p>
              Welcome to FakeGuard AI. By accessing or using our services, you agree to be bound by these Terms of Use.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">1. Acceptance of Terms</h3>
            <p>
              By accessing or using the FakeGuard AI platform, website, mobile application, or any other services provided by MetalMindTech (collectively, the "Services"), you agree to be bound by these Terms of Use. If you do not agree to these terms, you may not use our Services.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">2. Description of Services</h3>
            <p>
              FakeGuard AI provides artificial intelligence-powered product authentication services that allow users to scan and verify the authenticity of various products. Our technology analyzes images and provides an assessment of whether a product is likely authentic, suspicious, or counterfeit.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">3. User Accounts</h3>
            <p>
              To access certain features of our Services, you may be required to register for an account. You are responsible for maintaining the confidentiality of your account information and for all activities that occur under your account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">4. Subscription and Payment</h3>
            <p>
              Our Services may offer subscription plans or pay-per-use options. By selecting a subscription plan or making a payment, you agree to pay the specified fees. All fees are non-refundable except as required by law or as explicitly stated in our refund policy.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">5. Intellectual Property</h3>
            <p>
              All content, features, and functionality of our Services, including but not limited to text, graphics, logos, icons, images, audio clips, digital downloads, data compilations, software, and the compilation thereof, are owned by FakeGuard AI, its licensors, or other providers of such material and are protected by copyright, trademark, patent, trade secret, and other intellectual property or proprietary rights laws.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">6. Limitation of Liability</h3>
            <p>
              In no event shall FakeGuard AI, its officers, directors, employees, or agents, be liable to you for any direct, indirect, incidental, special, punitive, or consequential damages whatsoever resulting from any (i) errors, mistakes, or inaccuracies in the content; (ii) personal injury or property damage, of any nature whatsoever, resulting from your access to and use of our Services; (iii) any unauthorized access to or use of our secure servers and/or any and all personal information and/or financial information stored therein; (iv) any interruption or cessation of transmission to or from our Services; (v) any bugs, viruses, trojan horses, or the like, which may be transmitted to or through our Services by any third party; and/or (vi) any errors or omissions in any content or for any loss or damage of any kind incurred as a result of your use of any content posted, transmitted, or otherwise made available via the Services, whether based on warranty, contract, tort, or any other legal theory, and whether or not the company is advised of the possibility of such damages.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">7. Governing Law</h3>
            <p>
              These Terms shall be governed and construed in accordance with the laws of the United States, without regard to its conflict of law provisions. Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">8. Changes to Terms</h3>
            <p>
              We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">9. Contact Us</h3>
            <p>
              If you have any questions about these Terms, please contact us at legal@fakeguard.com.
            </p>
          </div>
        </DialogContent>
      </Dialog>
      
      <Dialog open={showDisclaimer} onOpenChange={setShowDisclaimer}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Disclaimer</DialogTitle>
            <DialogDescription>
              Last updated: January 1, 2025
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 text-sm">
            <p>
              FakeGuard AI provides product authenticity assessment services. Please read this disclaimer carefully before using our services.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">Accuracy Limitations</h3>
            <p>
              While we strive to provide accurate assessments, FakeGuard AI makes no warranties, express or implied, regarding the accuracy, reliability, or completeness of our authenticity scans. Our artificial intelligence technology is continuously improving but has inherent limitations. The assessment results provided by our Services should be considered as one of several factors in determining a product's authenticity, not as definitive proof.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">Not a Substitute for Professional Authentication</h3>
            <p>
              FakeGuard AI is not a substitute for professional authentication services. For high-value items or situations requiring absolute certainty, we recommend consulting with authorized dealers, brand representatives, or professional authenticators who can physically inspect the product.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">Image Quality Impact</h3>
            <p>
              The accuracy of our assessment depends significantly on the quality and clarity of the images provided. Poor lighting, blurry images, inadequate angles, or insufficient detail may result in inconclusive or incorrect assessments. Users are responsible for providing clear, well-lit images that adequately capture the product details.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">Product Scope</h3>
            <p>
              Our technology may be more effective for certain product categories than others. Some counterfeit products are increasingly sophisticated and may be difficult to distinguish from authentic items through image analysis alone. We continuously expand and improve our product recognition capabilities, but gaps in coverage exist.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">No Legal Advice</h3>
            <p>
              The information provided by FakeGuard AI does not constitute legal advice and should not be used as evidence in legal proceedings without additional verification. We do not provide authentication certificates that are legally binding or recognized by courts or law enforcement agencies.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">Third-Party Information</h3>
            <p>
              Any third-party information, references, or links provided through our Services are for informational purposes only. We do not endorse, control, or guarantee the accuracy of any third-party content.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">Changing Technology</h3>
            <p>
              As counterfeit production techniques evolve, our detection methods must also evolve. What may be detectable today may not be in the future. We strive to continuously update our technology but cannot guarantee detection of all counterfeit products at all times.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">Consumer Protection</h3>
            <p>
              This disclaimer does not affect your statutory consumer rights. If you believe you have purchased a counterfeit product, we recommend contacting the retailer, manufacturer, and relevant consumer protection agencies regardless of our assessment results.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">Contact Information</h3>
            <p>
              If you have questions about this disclaimer, please contact us at legal@fakeguard.com.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </footer>
  );
}