import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function FileManifest() {
  const files = [
    {
      type: "entity",
      path: "entities/ScanResult.json",
      description: "Stores scan results and analysis data"
    },
    {
      type: "entity",
      path: "entities/UserProfile.json",
      description: "Stores user profile information and achievements"
    },
    {
      type: "component",
      path: "components/scanner/CameraCapture.jsx",
      description: "Handles camera access and image capture"
    },
    {
      type: "component",
      path: "components/scanner/ScanResult.jsx",
      description: "Displays scan results and authenticity assessment"
    },
    {
      type: "component",
      path: "components/dashboard/StatsOverview.jsx",
      description: "Shows key metrics and statistics"
    },
    {
      type: "component",
      path: "components/dashboard/ScanHistory.jsx",
      description: "Lists previous scan results"
    },
    {
      type: "component",
      path: "components/dashboard/TrendAnalysis.jsx",
      description: "Visualizes scan trends over time"
    },
    {
      type: "component",
      path: "components/legal/Footer.jsx",
      description: "Site footer with legal links"
    },
    {
      type: "component",
      path: "components/legal/LegalDisclaimer.jsx",
      description: "Legal disclaimers and terms"
    },
    {
      type: "page",
      path: "pages/Scanner.js",
      description: "Main scanning interface"
    },
    {
      type: "page",
      path: "pages/Dashboard.js",
      description: "Analytics dashboard"
    },
    {
      type: "page",
      path: "pages/Profile.js",
      description: "User profile page"
    },
    {
      type: "page",
      path: "pages/ExportGuide.js",
      description: "Documentation for exporting the app"
    },
    {
      type: "layout",
      path: "Layout.js",
      description: "App layout with navigation"
    }
  ];

  const getBadgeColor = (type) => {
    switch (type) {
      case "entity": return "bg-green-100 text-green-800";
      case "component": return "bg-blue-100 text-blue-800";
      case "page": return "bg-purple-100 text-purple-800";
      case "layout": return "bg-amber-100 text-amber-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>File Export Manifest</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {files.map((file, index) => (
            <div key={index} className="flex flex-col md:flex-row md:items-center p-3 border rounded-md hover:bg-gray-50">
              <div className="flex-grow">
                <Badge className={getBadgeColor(file.type)}>
                  {file.type}
                </Badge>
                <p className="mt-1 font-mono text-sm">{file.path}</p>
              </div>
              <p className="text-sm text-gray-600 mt-2 md:mt-0">{file.description}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}